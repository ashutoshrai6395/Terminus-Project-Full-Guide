# Step 2a: Validate a Seed and Produce One Authoring Spec

Validate the supplied task idea and produce exactly one Step-2b authoring spec at:

```text
specs/<task-name>.md
```

Do not create any files under `tasks/`.
Do not draft `instruction.md`, `task.toml`, tests, a Dockerfile, or a solution.
Do not create a reviewer appendix or other human-handoff sidecar.
Do not use old task transcripts, rejected attempts, reviewer appendices, or
legacy validation sidecars as design sources.

> **Current category policy overrides older repository wording:** net-new tasks
> are allowed only in `machine-learning`, `games`, and
> `system-administration`.

---

## 1. Initialize the validation workflow

Run first:

```bash
python3 scripts/tb3_doctor.py
python3 scripts/agent_brief.py --mode task-author
```

Then run:

```bash
python3 scripts/validate_loop.py init <task-name>
```

Read the `ACTION` line from the output and follow it exactly.

Use these sources as the active authoring contract:

- `@idea-validation.mdc` for checks, rubric axes, evidence, and spec format
- `@instruction-prompt-styling.mdc`
- `docs/INSTRUCTION_PROMPT_STYLING.md`
- `@terminus-blockers.mdc`
- `@difficulty-calibration.mdc`
- `docs/HARD_BUT_FAIR_AUTHORING.md`
- `specs/validation_schema.json`

When older documentation conflicts with the category policy in this prompt,
this prompt wins for category eligibility.

---

## 2. Category gate — blocking and first

### Accepted categories — exactly 3

The spec must use exactly one of:

```text
machine-learning
games
system-administration
```

### Blocked categories

Reject any seed whose real primary activity belongs to:

```text
build-and-dependency-management
security
scientific-computing
data-processing
debugging
software-engineering
```

Do not continue merely by changing the `category` field.

If the idea is fundamentally blocked-category work, return `STOP` and explain
that it requires a new domain design. Do not launder or cosmetically remap it.

### Category-integrity test

Before attempt 1, answer:

1. What accepted-domain system is being operated, reconstructed, or made
   correct?
2. Which domain-specific invariants make it ML, Games, or System
   Administration?
3. If the category line and obvious domain nouns were removed, would a reviewer
   still recognize the accepted category?
4. Is any blocked-category activity only incidental and subordinate?

A seed fails category integrity when the answer to question 3 is no or the
answer to question 4 is no.

Use `CATEGORY_PRIMARY_ACTIVITY` from `scripts/tb3_categories.py` and the active
rules in `@idea-validation.mdc` where compatible with the current three-category
policy.

### Accepted repair tasks

`repair_existing_system` remains permitted only when:

- the underlying system is unmistakably ML, Games, or System Administration;
- the hard work is restoring accepted-domain behavior and invariants;
- the task is not a generic “find and fix the bug” exercise;
- the repair spans coordinated domain components rather than one obvious
  function;
- public instructions describe symptoms and required observable behavior
  without revealing root cause or patch location;
- every tested contract remains discoverable from public materials.

For repair tasks, `debugging` must never be used as the category or primary tag.

### No category laundering

Reject examples such as:

- generic codebase repair with game-themed filenames,
- file transformation labeled ML because a dataset is present,
- dependency or CI repair labeled sysadmin,
- authorization or cryptographic work labeled sysadmin,
- numerical simulation labeled ML without model-specific behavior,
- ordinary application logic labeled games without game mechanics,
- a parser, serializer, or report generator whose real work is data processing.

---

## 3. Milestones — blocked

If the seed plans any of the following, return `STOP` unless the design can be
converted into one standard task without weakening it:

```text
milestone_count > 0
number_of_milestones > 0
steps/milestone_N
```

Net-new milestone tasks are rejected.

The authoring spec must use:

```text
milestone_count: 0
```

and the standard single-task layout.

---

## 4. Implementation language

The seed must name exactly one implementation-language family from:

1. Python
2. JavaScript
3. TypeScript
4. Go
5. Rust
6. Java
7. C / C++
8. Ruby
9. Bash / Shell

Do not default to Python.

If the seed omits a language, select the best-fitting accepted family based on
the proposed system and record the rationale in the spec. Do not interrupt the
workflow merely to ask for a language unless choosing one would materially
change the task design.

Use only the language tags allowed by `@task-creation.mdc` § Accepted
implementation languages.

---

## 5. Uniqueness and distinct construction — blocking

The task must not be a reskin of an existing seed, spec, task, or successful
template.

Distinctness must cover the material construction, including:

- topology,
- primary domain invariant,
- failure-mode family,
- artifact shape,
- verifier shape,
- environment architecture,
- solution topology,
- state-transition or recovery mechanism.

Changing nouns, services, models, maps, datasets, filenames, or themes is not a
new construction.

Before attempt 1, run:

```bash
python3 scripts/seed_uniqueness_check.py check \
  --seed-id <seed-id> \
  --topology "<topology phrase>" \
  --category <machine-learning|games|system-administration> \
  --task-name <planned-slug>
```

Reject on a slug or topology collision and also manually reject substantive
construction collisions not detected by the script.

After the validation loop reaches GO, register the seed:

```bash
python3 scripts/seed_uniqueness_check.py register \
  --seed-id <seed-id> \
  --topology "<topology phrase>" \
  --category <machine-learning|games|system-administration> \
  --task-name <task-slug> \
  --task-shape <task_shape>
```

Do not register a STOPped seed.

---

## 6. Hard-only gate

GO is forbidden when the task is expected to land Easy or Medium.

Required target:

```text
predicted_worst_model_pass_rate <= 20%
```

The task must remain hard after every tested rule, schema, invariant, formula,
constant, and event contract is honestly disclosed.

Hardness must come from coordinated domain reasoning, not from:

- hidden requirements,
- misleading wording,
- undocumented constants,
- inaccessible dependencies,
- flaky external state,
- oversized inputs alone,
- timing or latency thresholds,
- requiring the agent to inspect tests,
- one obscure bug,
- brittle golden-output matching.

For Python tasks, run the applicable `hard_difficulty_predictor.py` workflow and
require a predicted worst-model pass rate at or below 20% before Step 2b.

Record:

```text
predicted_gpt5_pass_rate
predicted_claude_pass_rate
predicted_worst_model_pass_rate
```

---

## 7. Required authoring-spec and evidence fields

Both the markdown authoring spec and the structured evidence JSON must include
all fields required by the active schema, including:

- `platform_files`
- `task_files`
- `fix_frontier`
- `contract_surface`
- `task_shape`
- `category_profile`
- `satisfiability_risk`
- `actionability_plan`
- `waiver_plan`
- `reference_pattern`
- `realism_source`
- `difficulty_mechanism_plan`
- `calibration_plan`
- `verifier_scoring_plan`
- `subtype_milestone_plan`

For `realism_source`, preserve:

- `source_type`
- `evidence_basis`
- `upstream_or_synthetic_rationale`
- `minimization_preserves`
- `synthetic_exception_review`

For `reference_pattern`:

- use `reference_task_id` when a promoted reference applies;
- use `justification_if_none` only when no promoted reference fits;
- do not leave both fields blank;
- do not invent a promoted reference.

For `subtype_milestone_plan`, explicitly record that milestones are disabled for
the net-new task.

---

## 8. Public instruction planning

Plan a natural, human task prompt. The old six-heading bug-report checklist is
internal only; public headings are optional.

For `repair_existing_system`:

- use symptoms-only framing;
- disclose observable failures and required behavior;
- disclose commands, artifact contracts, schemas, and externally tested rules;
- do not reveal root cause, fix location, function names, patch sequence, or
  oracle transcript;
- do not hide required behavior to preserve difficulty.

For non-repair shapes:

- make behavior, constraints, schemas, and acceptance criteria complete;
- keep the implementation path solution-open;
- avoid answer-recital instructions that map each rule to one obvious module.

The public instruction must be sufficient without reading `tests/`, while still
requiring meaningful codebase or system engagement.

---

## 9. Validation loop

Repeat until `ACTION` is `GO` or `STOP`.

### On `ACTION: CONTINUE`

1. Confirm category eligibility before any hardness work.
2. Evaluate the 5 hardness axes from `@idea-validation.mdc`.
3. Run the instruction-completeness test:
   - Can the agent understand every required behavior without reading tests?
   - If no, FAIL for hidden contract.
   - Can the agent solve solely by reciting the instruction without engaging
     with the supplied system?
   - If yes, FAIL for collapse.
4. Run the post-disclosure collapse test:
   - after all externally tested rules are public, does the work reduce to
     mapping each rule to one obvious module or function?
   - if yes, FAIL;
   - never hide a rule to avoid this result.
5. Run all 21 anti-trivialization checks with reasoning before each verdict.
6. Evaluate all 6 rubric axes with explicit reasoning and verdicts.
7. Run `@difficulty-calibration.mdc` Part A collapse audit and the applicable
   platform auto-eval analysis.
8. Confirm at least 4 distinct difficulty mechanisms are central.
9. Confirm at least 3 concrete frontier-model failure modes.
10. Confirm the implementation or repair frontier spans at least 3 meaningful
    roots and that no one root contains more than 50% of the required work,
    unless the active schema explicitly permits and justifies a different
    concentration.
11. Confirm the verifier:
    - recomputes results independently where practical;
    - covers variants, not only one golden fixture;
    - rejects local partial fixes;
    - tests public contracts only;
    - does not award required behaviors without a falsifying case.
12. If attempt 2+, name the structural change that resolved each previous
    WARN/FAIL.
13. Name every design change beyond direct issue repair.
14. Run the naming pass and token-provenance audit:
    - draft shape-appropriate public instruction prose;
    - extract meaningful domain nouns;
    - populate
      `naming_pass.instruction_nouns_extracted` and
      `construction_manifest.code_forbidden_tokens`
      from the same reviewed list;
    - exclude common, standard-library, and generic terms rejected by the
      validator;
    - audit symbols, path tokens, decoys, fixture names, and planned test names
      for leakage;
    - record honest renames;
    - calculate concentration values honestly.
15. Build structured evidence matching `specs/validation_schema.json`.
16. Count FAILs and WARNs and make the score agree with the structured verdicts.
17. Produce one complete authoring spec in context. Do not save it yet.
18. Save evidence to:

```text
/tmp/<task-name>-validation-evidence.json
```

19. Record the result before saving the spec:

```bash
python3 scripts/validate_loop.py record <task-name> \
  --strict \
  --evidence /tmp/<task-name>-validation-evidence.json
```

20. Read `SAVE_TO` from the script output.
21. Save the authoring spec only to `SAVE_TO`, and only after `record`.
22. Ignore any legacy sidecar path unless diagnosing `validate_loop` itself.
    Step 2b must consume only the authoring spec.
23. Continue according to the new `ACTION`.

### When the loop reaches `ACTION: GO`

Run:

```bash
python3 scripts/validate_loop.py finalize <task-name>
python3 scripts/lint_spec.py specs/<task-name>.md --strict
python3 scripts/spec_satisfiability.py specs/<task-name>.md --strict
python3 scripts/category_coverage.py --tasks-dir tasks --json
python3 scripts/reference_task_check.py specs/<task-name>.md --strict
```

Also confirm manually that the finalized spec category is exactly one of:

```text
machine-learning
games
system-administration
```

If a gate fails, amend only evidence-consistent spec text, update evidence when
required, and rerun the same gate. Do not draft task files.

### On `ACTION: SELECT`

Compare candidate authoring specs only.

Ignore legacy sidecars unless diagnosing `validate_loop`.

For every candidate:

1. rerun category integrity;
2. rerun the post-disclosure collapse audit;
3. compare construction novelty;
4. compare verifier strength;
5. compare predicted worst-model pass rate;
6. reject any candidate with blocked-category leakage.

Select the strongest valid candidate:

```bash
python3 scripts/validate_loop.py select <task-name> \
  --winner <attempt-number-or-listed-path>
```

### On `ACTION: STOP`

Stop immediately when the seed cannot satisfy category integrity,
hard-but-fairness, uniqueness, verifier feasibility, or the hard-only bar
without becoming a materially different idea.

Do not force a GO by weakening evidence or changing labels.

---

## 10. Final report

When the loop ends, report:

- Final decision: `GO` or `STOP`
- Winning attempt number, if GO
- Accepted category
- Implementation language
- Stopping reason or GO rationale
- Final FAIL count
- Final WARN count
- Predicted worst-model pass rate
- Authoring spec path, if GO: `specs/<task-name>.md`

If GO, stop. Do not create files under `tasks/` in this conversation.

---

# Task idea

## Terminal Roguelike FOV Symmetry

- **seed_id**: `terminal-roguelike-fov-symmetry`
- **planned_task_slug**: `terminal-roguelike-fov-symmetry`
- **status**: `bank-ready`
- **category**: `games`
- **implementation_language**: `python`
- **topology**: `quadrant shadow state coupling`
- **construction_approach**: reconstruct symmetric field-of-view behavior
  across shadow intervals, dynamic door state, and downstream AI perception,
  with verifier-generated map transformations and replay comparisons
- **primary_domain_invariant**: equivalent map states related by reflection or
  quadrant rotation must produce correspondingly transformed visibility and AI
  perception, while corner-blocking and dynamic-door rules remain valid

### task_shape

- **type**: `repair_existing_system`
- **instruction_framing**: `symptoms-only`
- **hardness_source**: coupled game-rule invariant reconstruction
- **collapse_risk**: the prompt names the broken FOV helper, exposes the patch
  sites, or reduces the work to one boundary condition

### category_profile

- **primary_activity**: restore deterministic roguelike visibility and
  perception semantics across coupled game-engine subsystems
- **challenge_family**: grid visibility and game-state simulation
- **failure_family**: symmetry, corner occlusion, and dynamic-state propagation
- **profile_name**: `deterministic_game_simulation`
- **accepted_category_anchor**:
  - roguelike field-of-view rules,
  - dynamic door and tile-state transitions,
  - AI perception derived from player-visible world state,
  - deterministic map-symmetry behavior
- **blocked_adjacency_review**: repair work is subordinate to Games-domain
  simulation invariants; this is not generic debugging, serialization, or data
  processing
- **allowed_instruction_disclosures**:
  - public commands,
  - observable visibility and AI-perception symptoms,
  - map and trace schemas,
  - corner-occlusion rules,
  - symmetry and determinism contracts,
  - required generated artifacts
- **forbidden_instruction_leaks**:
  - root cause,
  - fix location,
  - broken helper names,
  - patch recipe,
  - oracle transcript,
  - direct recital of the three planned defect sites
- **category_specific_hardness_bar**: at least three coordinated game systems
  must reconcile: FOV interval propagation, dynamic map-state transitions, and
  downstream AI perception or replay state
- **category_specific_verifier_risks**:
  - false green from testing only one quadrant,
  - false green from static maps without door transitions,
  - false green from checking rendered visibility but not AI perception,
  - false green from golden fixtures without transformed variants
- **coverage_role**: distinct Games coverage for deterministic visibility,
  symmetry, and dynamic-state coupling in `repair_existing_system`

### satisfiability_risk

- **rc2_planned_name_risk**: `low` — use neutral names and avoid fix-path
  vocabulary
- **gx9_contract_risk**: `low` — expose map, trace, and visibility contracts
  through public artifacts rather than verdict booleans
- **cr1_symbol_frontier_risk**: `low` — plan a frontier across FOV computation,
  world-state propagation, and AI/replay consumption
- **hidden_contract_risk**: `low` — every externally tested symmetry,
  occlusion, transition, and output rule must be solver-visible
- **category_laundering_risk**: `low` — primary work is game simulation
  correctness, not generic repair

### actionability_plan

- **verifier_command_visible**: expose the primary game-simulation verification
  command
- **source_fix_intent_visible**: `no` — symptoms-only repair framing
- **generated_output_rule_visible**: document visibility traces, transformed-map
  results, and AI-perception observations
- **exact_formula_home**: public artifact or instruction for any externally
  tested slope, interval, or octant-transformation rule
- **schema_home**: public artifact for map, trace, replay, and observation
  structures

### waiver_plan

- **waivers_expected**: `no`
- **waiver_rationale**: hardness comes from coupled game behavior, transformed
  variants, and state propagation rather than harness brittleness

### reference_pattern

- **reference_task_id**: ``
- **justification_if_none**: no promoted reference is known to match the
  combination of roguelike FOV symmetry, dynamic-door propagation, and
  downstream AI-perception verification

### realism_source

- **source_type**: `real_system`
- **evidence_basis**: open-source roguelike visibility and shadow-casting
  failure patterns
- **upstream_or_synthetic_rationale**: grounded in production game-engine
  failures where local FOV corrections diverge across octants or fail to
  propagate dynamic world state
- **minimization_preserves**: causal coupling among shadow intervals, map-state
  transitions, and downstream perception
- **synthetic_exception_review**: `not required for real source`

### discoveries and design insights

Keep these internal to the spec and evidence. Do not copy them into the public
instruction as root-cause hints.

- quadrant-boundary interval handling can violate reflection symmetry;
- final-tile transparency handling can alter downstream shadow propagation;
- door-state updates can reach rendering but fail to invalidate or update the
  perception path;
- a local FOV fix may pass one orientation while failing rotated or reflected
  maps;
- visibility output and AI perception may disagree after a state transition.

### difficulty_mechanism_plan

At least these mechanisms must be central:

1. cross-component invariants,
2. transformed-map variant ladder,
3. order-sensitive dynamic-door state transitions,
4. deterministic replay or repeated-run consistency,
5. local-visibility versus downstream-perception agreement,
6. nonlocal consequences of interval-boundary changes.

### predicted model failure modes

At least these concrete failures must be evaluated:

1. patching one octant or quadrant while leaving reflected cases asymmetric;
2. correcting visible tiles but not downstream AI-perception state;
3. updating door state without invalidating stale visibility or replay state;
4. overfitting to supplied maps instead of honoring transformations;
5. fixing corner peeking while breaking open-space visibility;
6. producing correct final output but nondeterministic transition traces.

### verifier shape

The verifier should independently derive expected invariants from public map and
rule contracts rather than rely only on fixed golden outputs.

It should include:

- base maps plus reflected and rotated variants,
- closed-to-open and open-to-closed door transitions,
- repeated-run determinism,
- agreement between rendered visibility and AI perception,
- corner-blocking and open-space controls,
- at least one case that falsifies each required behavior,
- mutation resistance against local constant patches and single-quadrant fixes.

### hardness anchors

- edge-case map geometry,
- transformed variants,
- cross-file and cross-component invariants,
- dynamic state transitions,
- deterministic replay,
- independent verifier recomputation.

### main rejection risks

Reject or redesign if:

- the public prompt names the broken module or helper;
- all failures reduce to one off-by-one patch;
- AI perception is merely a duplicate boolean of visibility;
- the verifier uses only fixed golden fixtures;
- the task can be solved without understanding game FOV semantics;
- the implementation frontier does not genuinely span multiple roots;
- required rules remain hidden in tests;
- the task is presented as generic debugging instead of Games-domain repair.

### strengthening direction

Prefer structural strengthening through transformed map variants, dynamic state
transitions, and cross-consumer consistency. Do not add hidden rules, arbitrary
complexity, timing thresholds, or unrelated defects.
