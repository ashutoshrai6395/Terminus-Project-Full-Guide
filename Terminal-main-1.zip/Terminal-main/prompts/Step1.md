# Step 1: Idea Generation (ChatGPT)

Use these two prompts in order.

> **Effective immediately:** only `machine-learning`, `games`, and
> `system-administration` are permitted. Any older prompt, rule, example, mode,
> registry entry, or category list that allows another category is superseded
> for net-new task generation.

## Prompt 1 — Option B: Build the seed bank

Run Option B from `web/bulk-idea-generation.md` in goal-sized **full-bank**
mode, but override any older `full-six` wording and operate in **full-three**
mode using only the three accepted categories below.

The bank is being prepared for a final Option A output of exactly **150
Step-2a-ready seeds**, balanced as:

- 50 `machine-learning`
- 50 `games`
- 50 `system-administration`

Do not generate filler merely to meet the quota. Replace weak, repetitive,
misclassified, or blocked-category ideas with genuinely different seeds.

Return one downloadable `.md` seed-bank file.

For every seed:

1. Use exactly one accepted category.
2. Assign one implementation language from the 9 accepted language families.
3. Vary languages across the bank; do not default most seeds to Python.
4. Assign a unique `seed_id`.
5. Assign a distinct 3–6 word `Topology` token.
6. Name the construction approach in one line.
7. Use a distinct combination of:
   - task topology,
   - domain mechanism,
   - failure-mode family,
   - artifact shape,
   - verifier shape,
   - solution strategy.
8. Predict at least 3 concrete frontier-model failure modes.
9. Provide at least 4 distinct allowed difficulty mechanisms.
10. Reject the seed if its real primary activity is a blocked category.

Never clone an earlier recipe by changing nouns, filenames, services, game
themes, datasets, or model names.

## Prompt 2 — Option A: Refine and consolidate the bank

Run Option A from `web/option-a-seed-refinement.md` in `step2a-bank` mode
against the attached Option B seed-bank file.

Produce exactly **150 Step-2a-ready seeds**:

- 50 `machine-learning`
- 50 `games`
- 50 `system-administration`

Repair or replace weak seeds instead of shrinking the bank. Preserve exact
category balance while enforcing:

- category integrity,
- distinct topology within each category,
- construction-approach uniqueness,
- language diversity,
- hard-but-fair discoverability,
- verifier feasibility,
- no blocked-category leakage,
- no milestone tasks.

Return one downloadable `.md` file.

A seed must not survive refinement merely because its category field was
changed. If its primary work remains build management, security, scientific
computing, data processing, debugging, or general software engineering, replace
it with a genuinely in-category design.

---

## Accepted categories — exactly 3

Every seed must use exactly one of these `task.toml` categories:

1. `machine-learning`
2. `games`
3. `system-administration`

No other category is permitted for net-new submissions.

### Category targets

#### `machine-learning`

The primary work must concern an ML system, model, training or inference
workflow, checkpoint, feature/model contract, evaluation system, reproducibility
mechanism, or ML-specific runtime behavior.

Strong examples include:

- checkpoint and optimizer-state recovery,
- deterministic training resumption,
- training/inference contract alignment,
- model-serving state transitions,
- reproducible evaluation across variants,
- feature-schema and model-version compatibility,
- distributed training-state coordination,
- adversarial generalization across model or data variants,
- multi-stage ML pipeline invariants,
- inference batching or cache correctness tied to model semantics.

Reject generic scripts that merely parse datasets, transform files, calculate
metrics, or wrap an existing library without substantial ML reasoning.

#### `games`

The primary work must concern game rules, simulation, engine behavior, replay,
state transitions, world logic, agents, save systems, deterministic ticks,
multiplayer consistency, or game-specific correctness.

Strong examples include:

- deterministic replay reconstruction,
- rollback or lockstep state consistency,
- save-state migration with invariant preservation,
- entity-component-system interactions,
- game-rule adjudication across coupled subsystems,
- turn-order or tick-scheduler correctness,
- procedural-generation consistency,
- AI-agent state machines under game rules,
- resource/economy invariants,
- variant ladders across maps, rulesets, or scenarios.

Reject ordinary applications, generic algorithm exercises, or CRUD systems
with a game-themed vocabulary.

#### `system-administration`

The primary work must concern operating-system behavior, services, process
supervision, storage, filesystems, networking, namespaces, users and
permissions, configuration convergence, recovery, observability, or host
operations.

Strong examples include:

- service dependency and restart orchestration,
- journal or state reconstruction,
- filesystem, mount, or namespace recovery,
- idempotent host reconciliation,
- multi-service configuration convergence,
- process supervision and signal semantics,
- permission and ownership restoration,
- package/runtime state recovery as part of host administration,
- network routing, firewall, or name-resolution state,
- storage lifecycle and recovery across coordinated components.

A task may involve scripts or configuration files, but it must remain primarily
a system-administration task rather than generic coding, build repair, or
debugging.

---

## Blocked categories — forbidden

The following categories are blocked for net-new submissions:

| Blocked category | Required action |
|---|---|
| `build-and-dependency-management` | Reject; do not remap by renaming |
| `security` | Reject; do not disguise as sysadmin |
| `scientific-computing` | Reject; do not disguise as ML |
| `data-processing` | Reject thin parse/transform/aggregate work |
| `debugging` | Reject generic diagnosis-and-repair work |
| `software-engineering` | Reject generic implementation or codebase repair |

Also forbidden:

- net-new milestone tasks,
- `milestone_count > 0`,
- `number_of_milestones > 0`,
- generic codebase repair relabeled as an accepted category,
- thin ETL, parser, converter, migration, reporting, or aggregation tasks,
- generic dependency, compiler, linker, lockfile, build graph, or CI tasks,
- generic vulnerability, cryptography, authentication, authorization, or
  exploit-remediation tasks,
- generic numerical simulation or scientific-model tasks,
- tasks whose only hardness is locating a bug,
- tasks whose category depends only on filenames, nouns, or metadata,
- category tags such as `debugging` or `data-processing` used as the primary
  identity,
- recycled tasks with renamed entities,
- tasks that require reading hidden tests to discover the contract.

### Blocked-adjacency rule

An accepted-category task may contain incidental coding, parsing, diagnosis,
dependency use, numerical work, or security-sensitive configuration. However,
those activities must be subordinate to the accepted domain.

Reject the seed when removing its category label would cause a reviewer to
describe it primarily as any blocked category.

### Category integrity litmus

For every seed, answer all three questions:

1. What accepted-domain system is being operated, reconstructed, or made
   correct?
2. What domain-specific invariants make this ML, games, or sysadmin rather than
   generic coding or debugging?
3. Would the task still clearly belong to the selected category if the
   `category` field and obvious domain nouns were removed?

If question 3 is not an immediate **yes**, reject and redesign the seed.

### No category laundering

Do not remap blocked work using superficial substitutions, including:

- changing “application” to “game engine” without game mechanics,
- changing “data pipeline” to “ML pipeline” without model-specific behavior,
- changing “build environment” to “server environment” without host-operation
  semantics,
- changing “bug fix” to “state recovery” without a real recovery protocol,
- changing “security policy” to “system configuration” while authorization or
  threat prevention remains the core work,
- changing scientific computation to ML merely because Python or tensors are
  used.

---

## Unique seed and distinct construction — blocking

Every seed must be unique, not a renamed version of a prior seed, spec, task,
or successful template.

Before pursuing a seed in Cursor Step 2a:

1. Assign a unique kebab-case `seed_id`.
2. Assign a distinct 3–6 word `Topology` token.
3. Name the construction approach in one sentence.
4. Name the primary domain invariant.
5. Name the verifier shape.
6. Confirm that the topology, invariant, failure family, and construction
   approach do not duplicate an existing task.
7. Run the uniqueness check.

```bash
python3 scripts/seed_uniqueness_check.py check \
  --seed-id <your-seed-id> \
  --topology "<distinct topology phrase>" \
  --category <machine-learning|games|system-administration> \
  --task-name <planned-task-slug>
```

After Step 2a returns GO, register the seed:

```bash
python3 scripts/seed_uniqueness_check.py register \
  --seed-id <your-seed-id> \
  --topology "<distinct topology phrase>" \
  --category <machine-learning|games|system-administration> \
  --task-name <task-slug> \
  --task-shape <task_shape>
```

Audit existing collisions:

```bash
python3 scripts/seed_uniqueness_check.py audit
```

Reject a seed if it collides on any material combination of:

- topology,
- task slug,
- primary invariant,
- failure-mode family,
- construction approach,
- artifact shape,
- verifier strategy,
- solution path.

Renaming services, models, maps, files, datasets, or game entities does not make
a seed unique.

---

## Accepted implementation languages — 9 families

Use only these implementation-language families and vary them across the bank:

| # | Family | `task.toml` tags |
|---:|---|---|
| 1 | Python | `python` |
| 2 | JavaScript | `javascript` |
| 3 | TypeScript | `typescript` |
| 4 | Go | `go` |
| 5 | Rust | `rust` |
| 6 | Java | `java` |
| 7 | C / C++ | `c`, `cpp` |
| 8 | Ruby | `ruby` |
| 9 | Bash / Shell | `bash`, `shell` |

Full rules: `task-creation.mdc` § Accepted implementation languages.

Language selection must fit the proposed system. Do not force an unsuitable
language merely to create artificial diversity.

The final 150-seed bank must not be dominated by one family. Python may be used
where appropriate, especially for ML, but ML does not automatically imply
Python, and sysadmin does not automatically imply Bash.

---

## Required seed record

Every refined seed should contain at least:

```yaml
seed_id:
title:
planned_task_slug:
category:
task_shape:
implementation_language:
topology:
construction_approach:
primary_domain_invariant:
public_contract_summary:
required_artifacts:
solution_topologies:
difficulty_mechanism_plan:
predicted_model_failure_modes:
verifier_shape:
discoverability_sources:
uniqueness_notes:
predicted_gpt5_pass_rate:
predicted_claude_pass_rate:
predicted_worst_model_pass_rate:
rejection_risks:
```

Additional fields may be added when required by the active Step 2a schema.

---

## Hard-quality bar — blocking

Generate only ideas expected to remain genuinely hard after the full public
contract is disclosed.

Prefer seeds where:

- at least 3 nontrivial discovery items remain after honest disclosure,
- at least 3 plausible solution topologies exist,
- each viable solution requires at least 3 coordinated components,
- at least 4 distinct difficulty mechanisms are central,
- at least 3 realistic frontier-model failure modes are identifiable,
- the expected fix or implementation frontier spans at least 3 roots,
- no single root accounts for more than 50% of the necessary work,
- the verifier can distinguish partial local fixes from full correctness,
- variant cases defeat sample-specific or constant-specific solutions,
- category, language, topology, and verifier do not default to the last
  successful template.

Reject anything likely to land Easy or Medium, including ideas with predicted
worst-model pass rate above 20%.

Difficulty must come from domain reasoning and coordinated correctness, not
from hidden requirements, obscure wording, excessive runtime, missing
documentation, or test reverse-engineering.

---

## Allowed advanced-hardness centers

At least one advanced mechanism must be central to every seed.

### Machine learning

- checkpoint or optimizer-state recovery,
- deterministic resumption and reproducibility,
- training/inference semantic mismatch,
- feature/model version compatibility,
- distributed model-state coordination,
- model-serving state transitions,
- adversarial variant generalization,
- multi-stage ML invariant preservation,
- coupled data/model/evaluation contracts,
- numerically stable ML behavior tied to a public specification.

### Games

- deterministic simulation and replay,
- rollback or lockstep consistency,
- coupled game-rule invariants,
- save-state migration,
- entity-component interactions,
- tick or turn-order semantics,
- procedural-generation reproducibility,
- multi-agent state-machine interaction,
- game-economy or resource invariants,
- map/ruleset/scenario variant ladders.

### System administration

- state recovery,
- journal reconstruction,
- service dependency orchestration,
- idempotent configuration convergence,
- filesystem or namespace semantics,
- multi-service interaction,
- process and signal lifecycle behavior,
- storage recovery,
- routing or name-resolution convergence,
- host-state reconciliation across multiple sources of truth.

A listed mechanism is not sufficient by itself. It must materially shape the
contract, implementation, and verifier.

Timing and latency thresholds must not be used as the primary source of
difficulty.

---

## Difficulty mechanism requirement

Each seed's `difficulty_mechanism_plan` must list at least 4 distinct allowed
mechanisms.

Good mechanisms include:

- coupled invariants across components,
- order-sensitive state transitions,
- recovery from partially applied state,
- deterministic replay,
- cross-artifact consistency,
- idempotence under repeated execution,
- version or schema compatibility,
- variant-ladder generalization,
- multiple valid local states with one valid global state,
- adversarial boundary cases disclosed by the public contract,
- nonlocal consequences of local changes,
- verifier recomputation from independent public inputs.

Do not count the following as hardness mechanisms:

- timeouts,
- slow hardware,
- huge input volume alone,
- hidden constants,
- undocumented formats,
- misleading instructions,
- inaccessible dependencies,
- flaky external services,
- arbitrary test tricks,
- requiring agents to inspect test code.

---

## Model failure prediction

Before approving a seed, predict at least 3 realistic frontier-model failure
modes.

Each failure mode must name a concrete mistake, such as:

- restoring a checkpoint without optimizer or scheduler state,
- producing nondeterministic replay after a local game-state fix,
- restarting services in an order that violates dependency readiness,
- updating one schema consumer but not the other coordinated components,
- passing the visible case while failing a disclosed variant ladder,
- repairing a local invariant while violating a global state transition,
- making recovery non-idempotent,
- trusting stale derived state instead of recomputing from the public source of
  truth.

Reject generic entries such as:

- “wrong output,”
- “model gets confused,”
- “implementation bug,”
- “edge case failure,”
- “test failure.”

If fewer than 3 credible mistakes exist, reject the idea as insufficiently
deep.

---

## Idea rejection criteria

Reject any idea that:

- uses or primarily belongs to a blocked category,
- plans milestones,
- depends on hidden requirements,
- depends on undocumented constants, formulas, formats, or recovery rules,
- requires test reverse-engineering,
- is a simple CRUD application,
- is a straightforward API implementation,
- is a simple script,
- is a single-file bug fix,
- can be solved by editing one obvious function,
- is thin ETL, parsing, conversion, aggregation, or reporting,
- is a generic dependency/build/CI task,
- is a generic security task,
- is a generic scientific-computing task,
- is generic software implementation or codebase repair,
- is merely game-themed, ML-themed, or sysadmin-themed,
- lacks a feasible deterministic verifier,
- collapses to one obvious module after honest instruction disclosure,
- duplicates an existing topology or construction approach,
- predicts a worst-model pass rate above 20%.

Every tested behavior must be discoverable from `instruction.md`, documented
schemas, supplied fixtures, public configuration, and public APIs—not from
pytest or hidden implementation details alone.

---

## Python difficulty validation

This section applies when Python is the agent implementation language.

Before Step 2, estimate:

- `predicted_gpt5_pass_rate`
- `predicted_claude_pass_rate`
- `predicted_worst_model_pass_rate`

If `predicted_worst_model_pass_rate > 20%`, reject or redesign the seed.

Python tasks must target empirically hard difficulty. This applies to Python ML,
games, and sysadmin tasks alike.

Use the same pass-rate fields consumed by `reviewer_simulation.py` and
`scripts/hard_difficulty_predictor.py`.

Do not compensate for an easy Python task with hidden requirements, large
inputs, timing thresholds, or brittle tests.

---

## Final Step 1 acceptance checklist

Before returning the refined bank, confirm all of the following:

- [ ] Exactly 150 seeds are present.
- [ ] Exactly 50 seeds are `machine-learning`.
- [ ] Exactly 50 seeds are `games`.
- [ ] Exactly 50 seeds are `system-administration`.
- [ ] No blocked category appears as the real primary activity.
- [ ] No milestone task is present.
- [ ] Every seed has a unique `seed_id`.
- [ ] Every seed has a distinct topology and construction approach.
- [ ] Every seed names one accepted implementation-language family.
- [ ] Language distribution is intentionally varied.
- [ ] Every seed contains at least 4 difficulty mechanisms.
- [ ] Every seed contains at least 3 concrete model failure modes.
- [ ] Every seed has a deterministic, public-contract-based verifier plan.
- [ ] Every seed remains hard after honest disclosure.
- [ ] Every Python seed predicts worst-model pass rate at or below 20%.
- [ ] No seed is a noun-swapped copy of an existing seed, spec, or task.
- [ ] The output is one downloadable `.md` file ready for Step 2a selection.
