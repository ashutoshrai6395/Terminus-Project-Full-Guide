# Step 3b: Reviewer and Paper Review

Run this step only after Step 2b is complete and any Step 3a diagnostic has
been resolved.

This step performs a reviewer-style paper review of the completed task and its
fresh Step 2b evidence. It does not redesign, package, approve, or submit the
task.

> **Current category policy overrides older repository wording:** net-new tasks
> are allowed only in `machine-learning`, `games`, and
> `system-administration`.

Any open blocker is a hard failure or Needs Revision. Do not proceed to Step 4
while a blocker, stale-evidence condition, or unresolved warning remains.

---

## Paths

```text
Task path: tasks/<task-name>
Spec path: specs/<task-name>.md
Final oracle job directory: jobs/<oracle-job-dir>
Final NOP job directory: jobs/<nop-job-dir>
Gate report directory: /tmp/tb3-gates
```

Use the actual final Oracle and NOP job directories produced by the latest
successful Step 2b run. Do not point this review at an earlier or partial job.

---

## 1. Review sources and scope

Walk these policies end-to-end:

- `docs/TERMINUS_REVIEW_BLOCKERS.md`
- `@terminus-blockers.mdc`
- `docs/INSTRUCTION_PROMPT_STYLING.md`
- `@instruction-prompt-styling.mdc`
- `@review-and-submit.mdc` §1–§7
- `@difficulty-calibration.mdc` Part A, Part E, and Part F
- `docs/EDITION2_SUBMISSION_GUIDE.md`
- `docs/PLATFORM_AUTO_EVAL.md`

Apply current repository policy where documents differ.

Do not use old transcripts, legacy reviewer appendices, rejected versions,
obsolete job directories, or earlier task snapshots as evidence.

Do not:

- zip the task,
- run `approve_task.py`,
- package the task,
- submit the task,
- run Oracle 10 times,
- produce `ACCEPT` or `REJECT`.

Those actions belong to Step 4.

---

## 2. Step 2b evidence-readiness gate

Step 3b begins by verifying that the task and evidence are fresh.

Run:

```bash
python3 scripts/step2b_ready.py tasks/<task-name> --strict \
  --report-dir /tmp/tb3-gates \
  --oracle-job-dir jobs/<oracle-job-dir> \
  --nop-job-dir jobs/<nop-job-dir>
```

The readiness gate must confirm at least:

- Step 2b completed successfully;
- `.step2b-checksum` exists;
- the checksum matches the current task tree;
- required gate reports exist;
- the reports correspond to the current task contents;
- the supplied Oracle and NOP job directories exist;
- the jobs correspond to the current task version;
- Oracle completed successfully with full reward;
- NOP did not receive full reward;
- no task file changed after the recorded evidence;
- the spec and task remain compatible;
- the finalized category is allowed.

If readiness fails:

1. stop immediately;
2. record the exact stale or missing evidence;
3. return to Step 2b;
4. do not perform paper review against stale evidence.

Do not manually waive readiness failures.

---

## 3. Preservation discipline

Apply Preservation discipline before every task-file edit.

For a proposed edit:

1. state the exact issue;
2. predict which completed gates could be affected;
3. design the smallest preservation-safe correction;
4. verify that the correction does not alter the approved category, public
   contract, topology, output schema, discovery budget, verifier shape, or
   difficulty profile;
5. perform the edit only when it is appropriate for Step 3b;
6. self-check the actual diff against the prediction;
7. fire the dirty flag immediately.

An edit is not “review-only” merely because it is small.

Any change under `tasks/<task-name>/` invalidates Step 2b evidence, including:

- text edits,
- comments,
- formatting,
- metadata,
- test messages,
- dependency pins,
- executable bits,
- line endings,
- fixture changes,
- Dockerfile changes,
- solution changes.

Break an earlier gate only as a clearly labeled, justified regression when no
preservation-safe alternative exists. A justified regression still requires
returning to Step 2b.

Do not edit merely to make the review report cleaner.

---

## 4. Category-integrity review — blocking

### Accepted categories — exactly 3

The task must use exactly one of:

```text
machine-learning
games
system-administration
```

### Blocked categories

Net-new tasks are rejected when their real primary activity belongs to:

```text
build-and-dependency-management
security
scientific-computing
data-processing
debugging
software-engineering
```

A permitted category label does not cure blocked underlying work.

### Reviewer category test

Answer:

1. What accepted-domain system is the agent operating, reconstructing,
   repairing, or making correct?
2. Which domain-specific invariants make the task ML, Games, or System
   Administration?
3. Would a reviewer identify the accepted category if the category field, tags,
   and obvious domain nouns were removed?
4. Is every blocked-category activity incidental and subordinate?
5. Do `instruction.md`, `task.toml`, environment files, artifacts, and tests all
   support the same category?
6. Is the construction materially distinct from earlier tasks rather than a
   noun-swapped reskin?

Category integrity is `FAIL` when:

- question 3 or 4 is no;
- instruction, metadata, and verifier imply different primary activities;
- the task is generic code repair, implementation, ETL, build repair,
  security work, or scientific computation with an accepted-category label;
- accepted-domain behavior is only decorative.

### Accepted-domain anchors

#### Machine Learning

The core must involve model behavior, training, inference, checkpoint state,
feature/model compatibility, reproducibility, evaluation, serving, or another
ML-specific invariant.

Using Python, tensors, a dataset, or an ML library is insufficient by itself.

#### Games

The core must involve game rules, simulation, replay, save state, world state,
entity interaction, tick or turn semantics, multiplayer consistency,
procedural generation, game AI, or game-economy behavior.

A game theme or game-named files are insufficient by themselves.

#### System Administration

The core must involve operating-system or host administration, services,
supervision, processes, storage, filesystems, mounts, networking, namespaces,
users, permissions, configuration convergence, observability, recovery, or
machine-state reconciliation.

Using shell scripts, Docker, packages, or CI is insufficient by itself.

### Repair-task rule

A `repair_existing_system` task passes only when:

- its substrate is unmistakably an accepted domain;
- the work restores domain invariants;
- the task is not a generic find-the-bug exercise;
- multiple coordinated components matter;
- instructions use symptoms-only framing;
- every tested requirement is public;
- root cause and patch locations are not disclosed.

Never accept `debugging` as the category or primary task identity.

---

## 5. Structural review

Walk `@review-and-submit.mdc` §1–§7 and report `PASS`, `WARN`, or `FAIL` for
each section with one concise justification.

The required sections are:

1. Instruction
2. Environment
3. Oracle Solution
4. Verifiers
5. Task Metadata
6. Task Structure
7. Difficulty Calibration

A `WARN` must identify:

- the concrete risk;
- whether it can remain open;
- whether a policy-valid waiver exists;
- the required next action.

No unresolved `WARN` may proceed to Step 4.

---

## 5.1 Instruction review

Apply both the instruction rules and
`docs/INSTRUCTION_PROMPT_STYLING.md`.

Confirm:

- natural human voice;
- task-specific wording;
- concise, focused structure;
- no roleplay;
- no GPT-style filler;
- no emojis;
- no em dash or en dash punctuation;
- no curly quote dependency when repository style forbids it;
- no hints section;
- no detection-guidance section;
- no root-cause disclosure;
- no patch-location disclosure;
- no patch-order recipe;
- no oracle transcript;
- no test reverse-engineering requirement;
- no scenario-to-field-to-answer table that gives away the solution;
- every externally tested requirement is solver-visible;
- the primary verifier command is visible;
- output paths and schemas are exact;
- formulas, constants, labels, arguments, state rules, and invariants tested by
  the verifier are public;
- subsystem-level orientation is fair without revealing the fix.

For repair tasks, confirm the instruction is symptoms-only.

Run a text scan as part of the review, but do not edit automatically:

```bash
grep -nE '—|–|[[:cntrl:]]|hint|Hints|HINTS' \
  tasks/<task-name>/instruction.md || true
```

Interpret results manually. A matching word is not automatically a violation,
but every match must be reviewed.

### Instruction hard failures

`FAIL` when:

- a tested contract is hidden;
- the prompt names the broken function, file, or exact repair site;
- the prompt discloses the root cause;
- requirements are learnable only from tests;
- the prompt maps every disclosed rule to one obvious implementation site;
- style violations make the prompt look machine-generated or hint-driven.

---

## 5.2 Environment review

Confirm:

- every Docker `FROM` is digest-pinned;
- the canonical final runtime base is used when required;
- any allowed non-canonical base has a valid documented justification;
- the build context passes platform size limits;
- no environment file exceeds platform limits;
- no unnecessary large assets exist;
- all runtime and verifier dependencies are installed in the image;
- exact dependency pins follow current repository policy;
- `tests/test.sh` performs no runtime installation for an offline task;
- the image contains no `solution/` or `tests/`;
- the image contains no solved source, answer artifact, hidden golden, or
  generated output;
- no floating image tags are used;
- no `apt upgrade` is used;
- broad `chmod -R` is absent unless specifically justified;
- line endings and executable bits are correct;
- the image was rebuilt after the last Dockerfile or test-runner change.

Apt pins are point-in-time. If the build failed because a pinned version
disappeared after a repository security update, the pin must be refreshed using
the approved repository workflow. Do not remove version pins.

### Internet policy

Confirm `task.toml` contains an accurate:

```toml
[environment]
allow_internet = false
```

for offline tasks.

Use `true` only when the task genuinely requires an external resource during
agent execution.

Build-time package retrieval does not by itself justify runtime internet.

For offline tasks:

- all verifier dependencies must be in the Docker image;
- `tests/test.sh` must not invoke `apt-get`, `pip`, `curl`, `wget`, `uv`, or
  another bootstrap path;
- platform `test_deps_in_image` expectations must pass.

`gpus`, `gpu_types`, and `docker_flags` are optional and should not be required
without a real task need.

### Environment hard failures

`FAIL` when:

- any unpinned or unsanctioned image violates platform policy;
- dependencies are installed at verifier runtime for an offline task;
- the image contains solution or test leakage;
- internet is enabled merely for convenience;
- stale image evidence is used;
- the build context exceeds platform limits.

---

## 5.3 Oracle-solution review

Inspect every substantive operation in `solution/solve.sh`.

For each operation, confirm:

- the target exists in the unsolved task;
- the operation makes a substantive on-disk change;
- the change is necessary for the public contract;
- the operation is deterministic;
- the operation does not edit tests or verifier code;
- the operation does not manipulate reward files;
- the operation does not bypass validation;
- the operation does not hardcode hidden-test answers;
- the operation is comparable to a legitimate agent solution;
- the operation preserves alternate valid solution approaches;
- the operation contributes to the declared fix or implementation frontier.

A validation-only sanity command may exist, but it must be identified as such
and must not be counted as a substantive repair operation.

### Oracle hard failures

`FAIL` when:

- `solve.sh` edits tests;
- `solve.sh` edits reward or verifier control files;
- `solve.sh` edits a `decoy_manifest` path;
- an operation targets a missing file;
- an operation produces no substantive change;
- an operation only changes whitespace, a comment, or a marker;
- no-op operations inflate apparent complexity;
- answer literals are copied from hidden expectations;
- the solution relies on stale generated outputs;
- the solution succeeds only because of an oracle-specific path.

Record the oracle line count, but do not treat line count alone as difficulty.

---

## 5.4 Verifier review

Confirm:

- every asserted behavior is public;
- every required behavior has a falsifying case;
- tests verify semantics rather than oracle patch shape;
- tests are independently set up;
- shared state is reset where required;
- tests are deterministic;
- at least two valid implementation approaches can pass core behavior;
- fixed goldens are not the sole oracle when valid alternatives exist;
- agent-produced verdict booleans are independently recomputed where possible;
- variant or metamorphic cases prevent sample overfitting;
- partial-oracle ablations fail behaviorally;
- tests do not reward cosmetic or no-op changes;
- reward output is written correctly;
- failure before reward generation cannot be mistaken for task difficulty.

Build or inspect a requirement-to-test matrix containing:

- public requirement;
- disclosure location;
- positive case;
- falsifying case;
- variant case;
- independent recomputation;
- expected failing partial mutation.

### Verifier hard failures

`FAIL` when:

- a tested rule is hidden;
- a required behavior has no case capable of failing it;
- tests only match oracle literals;
- the NOP path can earn full reward;
- the verifier depends on execution order without controlled setup;
- a test passes because another test prepared its state;
- the verifier is flaky;
- reward generation is absent or unreliable;
- tests require one private implementation technique;
- a `flipping_point_contract.controls_tests` entry names a test that does not
  flip when the stated location is reverted.

If the spec names a `symbol_table`, `construction_manifest.json` must exist and
must be coherent with the built task.

---

## 5.5 Task metadata review

Confirm:

- category is exactly one accepted value;
- category profile matches the actual primary activity;
- tags reinforce rather than contradict the category;
- implementation-language tags are from the 9 accepted families;
- task shape matches the spec and instruction framing;
- difficulty metadata matches empirical evidence;
- `number_of_milestones = 0`;
- no milestone directory exists;
- `allow_internet` is accurate;
- timeouts and resources are realistic;
- artifact and objective metadata match actual outputs;
- reference metadata is complete.

### Reference pattern

Confirm the task uses either:

- a valid promoted `reference_task_id`; or
- a concrete `justification_if_none`.

Do not accept an empty promoted-reference field with a generic explanation.

Review the Step 2b `reference_task_check.py` result. If the current task no
longer matches that evidence, readiness must fail and Step 2b must be rerun.

### Metadata hard failures

`FAIL` when:

- category is blocked or laundered;
- metadata describes a different task from the built files;
- milestones are enabled;
- internet metadata is false;
- implementation language is missing or invalid;
- reference metadata is empty or fabricated.

---

## 5.6 Task-structure review

Confirm required files exist at task root:

```text
instruction.md
task.toml
output_contract.toml
construction_manifest.json
environment/Dockerfile
solution/solve.sh
tests/test.sh
tests/test_outputs.py
```

Confirm:

- `output_contract.toml` is repo-local authoring metadata;
- solver-visible requirements also appear in public surfaces;
- no `steps/milestone_N/` layout exists;
- no generated outputs, build artifacts, answer files, caches, or AI scaffolding
  are committed under `environment/`;
- file layout is realistic and no larger than needed;
- every substantive file has a real role;
- discovery-budget locations match the spec;
- path names do not reveal fixes;
- construction is distinct from prior tasks.

Do not require an arbitrary minimum number of files. More files do not
automatically mean more difficulty.

### Structure hard failures

`FAIL` when:

- required files are missing;
- task structure contradicts the spec;
- milestone files exist;
- answer leakage exists;
- dead files or cosmetic decoys inflate complexity;
- a missing construction manifest violates the approved spec;
- file topology is a renamed clone of a prior task.

---

## 5.7 Difficulty-calibration review

Confirm:

- the task remains hard after full contract disclosure;
- difficulty comes from accepted-domain reasoning;
- the frontier spans the coordinated components promised by the spec;
- no single obvious edit solves the task;
- no hidden requirement carries the difficulty;
- agent accuracy, when available, supports the claimed difficulty;
- the predicted worst-model pass rate remains at or below 20%;
- the verifier rejects partial local repairs;
- repeated failures do not come from verifier malfunction.

Empirical easy tasks are blocked.
Tasks expected to land Medium should return to Step 2a for strengthening.

Do not harden by:

- hiding requirements,
- increasing input size alone,
- adding timeouts,
- adding arbitrary constants,
- renaming symbols,
- adding fixed fixtures only,
- adding unrelated bugs,
- adding dead code or decoys.

---

## 6. Collapse audit

Run `@difficulty-calibration.mdc` Part A against the actual drafted files.

Report the complete audit:

1. smallest plausible successful patch;
2. likely editable frontier;
3. requirement-to-file map;
4. post-disclosure mapping;
5. oracle line count;
6. codebase size and discoverability;
7. fix-location findability;
8. dominant solution path;
9. red flags;
10. residual hardness;
11. collapse verdict: `PASS`, `WARN`, or `FAIL`.

### Post-disclosure question

After every externally tested rule, formula, invariant, constant, schema, state
transition, and output contract is visible:

- does each requirement map to one obvious function, module, or constant?
- can a model complete the task by mechanically transcribing the prompt?
- can the task be solved by one small local patch?
- is the remaining exploration genuine accepted-domain reasoning?

If the task collapses after honest disclosure, mark `FAIL`.
Do not hide a rule to preserve hardness.

### Advisory checker

Run:

```bash
python3 scripts/post_disclosure_collapse.py tasks/<task-name>
```

Include its `PASS` or `WARN` result and explain any discrepancy between the
script and manual review.

Treat this checker as advisory. A script PASS does not override a manual
collapse failure.

### Solution-operation audit

For every non-trivial `solve.sh` operation, record:

- target path;
- target existence;
- before/after substantive effect;
- public requirement served;
- whether reverting the operation causes a meaningful failure.

Cosmetic, marker-only, or no-op operations are hard failures.

---

## 7. Per-test feasibility review

Review every test function individually.

For each test report:

- test name;
- one-sentence behavior summary;
- public contract source;
- positive and falsifying coverage;
- single-valid-approach risk: `LOW`, `MEDIUM`, or `HIGH`;
- chain-dependency risk: `LOW`, `MEDIUM`, or `HIGH`;
- order-sensitivity risk: `LOW`, `MEDIUM`, or `HIGH`;
- flakiness risk: `LOW`, `MEDIUM`, or `HIGH`;
- niche-technique risk: `LOW`, `MEDIUM`, or `HIGH`;
- implementation-detail coupling risk: `LOW`, `MEDIUM`, or `HIGH`;
- verdict and required action.

### Risk rules

Escalate to Step 3a-V before Step 4 when any test has:

- `HIGH` chain-dependency risk;
- `HIGH` order-sensitivity risk;
- `HIGH` flakiness risk;
- unclear reward behavior;
- a verifier-health concern that paper review cannot settle;
- a suspected single-private-implementation requirement.

A `HIGH` niche-technique or implementation-detail risk is also blocking unless
the public contract legitimately requires that technique.

Do not edit tests during Step 3b and continue as though evidence remained
valid. Any test edit fires the dirty flag and returns the task to Step 2b.

---

## 8. Platform auto-eval readiness

Apply `@difficulty-calibration.mdc` Part F and
`docs/PLATFORM_AUTO_EVAL.md`.

Confirm:

- `tests/test.sh` performs no runtime package installation for offline tasks;
- `environment/Dockerfile` pre-installs pytest, plugins, agent tools, and all
  task runtimes;
- exact dependency pins match current policy;
- `allow_internet = false` for offline tasks;
- runtime internet is enabled only when genuinely required;
- the image was rebuilt after every Dockerfile or `test.sh` edit;
- `task_runtime_deps.py --strict` passed in fresh Step 2b evidence;
- the verifier writes the required reward artifact;
- reward generation occurs before difficulty interpretation;
- no `verifier_did_not_run` condition is being mistaken for agent failure;
- the final Oracle job passed fully;
- the final NOP job did not pass fully;
- final job evidence matches the current checksum.

Review the platform guidance for:

- build-time versus runtime network use;
- canonical Dockerfile and `test.sh` patterns;
- `verifier_did_not_run`;
- unexpected `0/10`;
- stale image behavior;
- reward-file ordering;
- dependency omissions.

### Auto-eval hard failures

`FAIL` when:

- an offline verifier installs packages at runtime;
- a required runtime is missing;
- reward output is missing or unreliable;
- the image is stale;
- the final job evidence is stale;
- Oracle failure is being treated as difficulty;
- NOP earns full reward;
- internet metadata and actual behavior disagree.

---

## 9. Blocker walk

Walk every relevant section of
`docs/TERMINUS_REVIEW_BLOCKERS.md` or `@terminus-blockers.mdc`.

For each blocker record:

- blocker identifier;
- applicability;
- evidence inspected;
- verdict;
- remediation or waiver;
- whether the task may proceed.

Any applicable open blocker is `FAIL`.

At minimum, explicitly check:

- category eligibility;
- category integrity;
- empirical difficulty;
- instruction completeness;
- instruction leakage;
- task realism;
- file and symbol frontier;
- construction uniqueness;
- verifier independence;
- test falsifiability;
- oracle legitimacy;
- Docker and dependency policy;
- offline execution;
- output contract consistency;
- milestone prohibition;
- reference-pattern validity;
- stale evidence;
- collapse;
- no-op or cosmetic solution actions.

---

## 10. Edit policy

Step 3b should normally review, not repair.

When a defect is found:

- report it precisely;
- identify whether it can be corrected without changing the Step 2a design;
- use Preservation discipline before any edit;
- if an edit is made, stop the current review after recording the edit;
- return to Step 2b;
- do not continue accumulating PASS claims on stale evidence.

Return directly to Step 2a when the required correction changes:

- category,
- task shape,
- public contract,
- output schema,
- file topology,
- symbol frontier,
- discovery budget,
- verifier strategy,
- language,
- instruction-disclosure level,
- central difficulty mechanisms.

---

## 11. Step 3b summary

Report:

1. readiness-gate result;
2. accepted category and category-integrity verdict;
3. structural review verdicts for all seven sections;
4. instruction-style verdict;
5. blocker-walk results;
6. complete Part A collapse audit;
7. advisory post-disclosure checker result;
8. solution-operation audit;
9. per-test feasibility table;
10. whether Step 3a-V was escalated;
11. platform auto-eval readiness;
12. edit ledger or explicit `No task files edited`;
13. unresolved warnings or failures;
14. next action.

### Next-action rules

Use exactly one:

#### Return to Step 2a

Use when a required correction materially changes the approved design.

#### Return to Step 2b

Use when:

- readiness failed;
- evidence is stale;
- any task file was edited;
- a construction defect requires a preservation-safe task correction;
- Step 2b mechanical or Harbor evidence must be regenerated.

#### Escalate to Step 3a-V

Use when verifier execution, isolation, ordering, flakiness, or implementation
coupling requires diagnostic evidence.

#### Stop: Needs Revision

Use when an open blocker, FAIL, or unresolved warning remains.

#### Ready for Step 4

Use only when:

- readiness passed;
- no task file was edited;
- every structural section passed;
- category integrity passed;
- blocker walk has no open item;
- collapse audit passed;
- per-test feasibility has no blocking risk;
- platform auto-eval readiness passed;
- no Step 3a-V escalation is pending.

Do not use `ACCEPT`.

---

# Step 3b to Step 4: Dirty-flag re-entry

Run this section only when Step 3a or Step 3b edited any file under:

```text
tasks/<task-name>/
```

The task changed after Step 2b evidence. The dirty flag has fired.

Do not:

- run Oracle 10 times;
- package;
- approve;
- submit;
- continue to Step 4.

First determine whether the edit preserved the finalized Step 2a design.

Return to Step 2a instead when the edit changed:

- category;
- task shape;
- public contract;
- output schema;
- file topology;
- symbol frontier;
- discovery budget;
- verifier shape;
- implementation language;
- instruction disclosure;
- central difficulty mechanisms.

For preservation-safe task edits, return to Step 2b and regenerate evidence.

Run:

```bash
python3 scripts/spec_satisfiability.py \
  specs/<task-name>.md \
  --task-dir tasks/<task-name> \
  --strict

python3 scripts/hard_difficulty_predictor.py \
  tasks/<task-name>

python3 scripts/task_runtime_deps.py \
  tasks/<task-name> \
  --strict

python3 scripts/task_gate.py \
  tasks/<task-name> \
  --strict \
  --report-dir /tmp/tb3-gates \
  --skip-harbor

./scripts/check-task.sh \
  --strict \
  --report-dir /tmp/tb3-gates \
  tasks/<task-name>

python3 scripts/harbor_gate.py \
  tasks/<task-name> \
  --oracle \
  --oracle-stress 3 \
  --nop \
  --nop-stress 3
```

Also rerun every collapse, verifier-health, mutation, or ablation check
invalidated by the edit.

After fresh Step 2b evidence exists:

1. use the new final Oracle job directory;
2. use the new final NOP job directory;
3. rerun `step2b_ready.py`;
4. rerun Step 3b from the category and structural review;
5. proceed to Step 4 only when the new Step 3b result is `Ready for Step 4`.

---

## Final prohibition

Step 3b ends with a review result only.

Do not zip.
Do not package.
Do not approve.
Do not submit.
Do not run Oracle 10 times.
Do not produce `ACCEPT` or `REJECT`.
