# Step 2b: Construct and Validate One Task

Create one task from the finalized Step 2a authoring spec:

```text
specs/<task-name>.md
```

Create task files only under:

```text
tasks/<task-name>/
```

This step constructs and validates the task. It does not package, approve, or
submit it.

> **Current category policy overrides older repository wording:** net-new tasks
> are allowed only in `machine-learning`, `games`, and
> `system-administration`.

---

## 1. Source-of-truth and scope rules

Follow:

- `@task-creation.mdc`
- `@terminus-blockers.mdc`
- `docs/TERMINUS_REVIEW_BLOCKERS.md`
- `@instruction-prompt-styling.mdc`
- `docs/INSTRUCTION_PROMPT_STYLING.md`
- `docs/HARD_BUT_FAIR_AUTHORING.md`
- `@review-and-submit.mdc` §1–§7
- `@difficulty-calibration.mdc` Part A and Part B
- `scripts/collapse_check.py` RC/GX/CR rules

Use the finalized authoring spec as the only task-specific design source.

Policy files may be read to apply repository rules. Do not use any of the
following as design sources:

- legacy reviewer appendices,
- `validate_loop` sidecars,
- old task transcripts,
- previous rejected attempts,
- prior oracle patches,
- unrelated completed tasks,
- model-generated scratch files.

Do not silently reinterpret or redesign the Step 2a spec during construction.

Return to Step 2a if an honest correction would materially change any of:

- category,
- task shape,
- public contract,
- output schema,
- required artifacts,
- file topology,
- symbol or fix frontier,
- discovery budget,
- verifier shape,
- instruction-disclosure level,
- difficulty mechanisms,
- implementation language.

Do not run oracle 10 times.
Do not package or approve the task.
Do not produce `ACCEPT` or `REJECT`.

---

## 2. Initialize

Run first:

```bash
python3 scripts/tb3_doctor.py
python3 scripts/agent_brief.py --mode task-author
```

Before drafting any task file, run:

```bash
python3 scripts/lint_spec.py specs/<task-name>.md --strict
python3 scripts/spec_satisfiability.py specs/<task-name>.md --strict
python3 scripts/category_coverage.py --tasks-dir tasks --json
python3 scripts/reference_task_check.py specs/<task-name>.md --strict
```

If `tasks/<task-name>/` already exists from an interrupted draft, run:

```bash
python3 scripts/lint_spec.py specs/<task-name>.md --strict
python3 scripts/spec_satisfiability.py \
  specs/<task-name>.md \
  --task-dir tasks/<task-name> \
  --strict
python3 scripts/category_coverage.py --tasks-dir tasks --json
python3 scripts/reference_task_check.py \
  specs/<task-name>.md \
  tasks/<task-name> \
  --strict
```

Do not continue on `FAIL`.

Treat each `WARN` as one of:

1. a construction issue that must be corrected without changing the spec;
2. a documented, policy-valid waiver;
3. evidence that the design must return to Step 2a.

Never ignore a warning merely to continue.

---

## 3. Category gate — blocking

### Accepted categories — exactly 3

Before creating files, confirm that the finalized spec uses exactly one of:

```text
machine-learning
games
system-administration
```

### Blocked categories

Do not construct a net-new task whose actual primary activity belongs to:

```text
build-and-dependency-management
security
scientific-computing
data-processing
debugging
software-engineering
```

This includes tasks that are cosmetically relabeled under an accepted category.

### Category-integrity test

Record answers before drafting:

1. What accepted-domain system is being operated, reconstructed, or made
   correct?
2. Which domain-specific invariants make it ML, Games, or System
   Administration?
3. Would the category remain obvious if the category field and obvious domain
   nouns were removed?
4. Is every blocked-category activity incidental and subordinate?

If question 3 or 4 fails, stop and return to Step 2a.

### Accepted-domain anchors

#### `machine-learning`

The central behavior must involve model, training, inference, checkpoint,
feature/model compatibility, evaluation, reproducibility, serving, or
ML-specific state semantics.

A dataset, tensor library, or Python codebase alone does not make a task ML.

#### `games`

The central behavior must involve game rules, simulation, replay, save state,
world state, entity interactions, turn or tick semantics, multiplayer
consistency, procedural generation, game AI, or game-economy invariants.

Game-themed names alone do not make a task Games.

#### `system-administration`

The central behavior must involve host or operating-system administration,
services, supervision, storage, filesystems, mounts, networking, namespaces,
users, permissions, configuration convergence, observability, recovery, or
machine-state reconciliation.

A shell script, Dockerfile, package failure, or CI workflow alone does not make
a task System Administration.

### Repair-task rule

`repair_existing_system` is allowed only when:

- the substrate is unmistakably one of the three accepted domains;
- the work restores domain behavior and invariants;
- the task is not generic “find the bug” work;
- multiple coordinated domain components are involved;
- the instruction uses symptoms-only framing;
- every tested behavior is publicly discoverable;
- root cause and patch location remain undisclosed.

Never use `debugging` as the category or primary tag.

### No category laundering

Return to Step 2a for tasks such as:

- generic app repair with game-themed files,
- parse/transform/aggregate work labeled ML,
- dependency, lockfile, compiler, linker, build, or CI repair labeled sysadmin,
- cryptography, authorization, vulnerability, or exploit work labeled sysadmin,
- numerical simulation labeled ML without model-specific behavior,
- generic implementation work with accepted-category vocabulary.

Changing only `category`, tags, filenames, or prose is not a valid correction.

---

## 4. Spec-handoff gate

Before construction, confirm the spec contains and coherently connects:

- category and category profile,
- task shape,
- implementation language,
- public contract,
- platform files,
- task files,
- environment shape,
- required artifacts,
- output schema,
- fix or implementation frontier,
- construction manifest,
- discovery budget,
- difficulty-mechanism plan,
- calibration plan,
- verifier-scoring plan,
- reference pattern,
- realism source,
- milestone plan.

The spec must set or imply:

```text
milestone_count = 0
number_of_milestones = 0
```

Return to Step 2a if required information is missing, contradictory, or
materially ambiguous.

Do not invent missing core contracts during Step 2b.

---

## 5. Language gate

Confirm that the spec names one accepted implementation-language family:

1. Python
2. JavaScript
3. TypeScript
4. Go
5. Rust
6. Java
7. C / C++
8. Ruby
9. Bash / Shell

Use the corresponding tags permitted by `@task-creation.mdc`.

Do not default to Python.
Do not change the language during Step 2b merely because another language is
easier to scaffold.

If the language is missing or materially incompatible with the spec, return to
Step 2a.

---

## 6. Construction discipline

Use the spec's:

- metadata,
- public contract,
- failure topology,
- environment architecture,
- required artifacts,
- construction manifest,
- discovery budget,
- test plan,
- verifier strategy,
- predicted model-failure modes.

Design the exact internal file tree and implementation scaffolding while
preserving the approved topology and difficulty profile.

The spec may intentionally leave internal implementation details open. Fill
those details without changing externally visible behavior or collapsing the
task to one obvious patch.

### Construction uniqueness

Do not clone a previous task's:

- file layout,
- failure topology,
- oracle patch pattern,
- fixture structure,
- verifier strategy,
- artifact schema,
- state-recovery mechanism,

and merely rename symbols.

The built task must realize the distinct construction approved in Step 2a.

### No artificial complexity

Do not create extra files, subsystems, decoys, dependencies, or indirection only
to inflate difficulty.

There is no arbitrary minimum file-count target.

Use the smallest realistic file tree that still realizes:

- the approved multi-component topology,
- the approved discovery budget,
- the approved fix or implementation frontier,
- the approved verifier coverage.

Every substantive file must have a real system role.

---

## 7. Public `instruction.md`

Write `instruction.md` as a natural accepted-task prompt.

Required style:

- human voice,
- varied wording across tasks,
- normally 1–3 focused paragraphs,
- no roleplay,
- no GPT-style filler,
- no emojis,
- no em dash or en dash punctuation,
- no “hints” section,
- no detection guidance,
- no step-by-step repair recipe,
- no root-cause disclosure.

It must reveal every externally tested requirement, including as applicable:

- source-fix or implementation intent,
- verifier command,
- required output files,
- generated-output rules,
- schemas,
- invariants,
- formulas,
- types,
- constants,
- profile labels,
- argument divisions,
- state-transition rules,
- subsystem-level orientation.

It must not reveal:

- exact patch files,
- exact functions or symbols to edit,
- root cause,
- patch order,
- internal repair recipe,
- oracle transcript,
- scenario-to-field-to-expected-answer tables,
- hidden test structure.

### Repair framing

For `repair_existing_system`:

- describe observable symptoms;
- state required final behavior;
- disclose public contracts and commands;
- avoid identifying the broken helper, module, or defect sites.

### Non-repair framing

For implementation or reconstruction shapes:

- disclose behavior and constraints completely;
- keep architecture and solution path open;
- avoid translating every requirement into an obvious implementation step.

### Actionability

An agent must be able to determine all required behavior from:

- `instruction.md`,
- solver-visible environment documentation,
- public source help,
- supplied schemas and fixtures.

The agent must not need to read hidden tests to learn the contract.

At the same time, the instruction must not collapse the work into answer
recitation.

### Metadata is not solver disclosure

`output_contract.toml`, `task.toml`, and authoring metadata do not by themselves
make a requirement solver-visible.

Every verifier-tested requirement must also appear in `instruction.md` or a
solver-visible environment surface.

---

## 8. Required task files

Create a standard single-step task under:

```text
tasks/<task-name>/
```

Required files:

```text
instruction.md
task.toml
output_contract.toml
construction_manifest.json
environment/Dockerfile
solution/solve.sh
tests/test.sh
tests/test_outputs.py
```

Also create every substantive environment file required by the approved spec.

Do not create:

```text
steps/milestone_N/
```

New milestone tasks are blocked.

Do not convert the design into a UI task or multi-container task when those
shapes are not accepted by the current platform rules.

---

## 9. Environment and Docker rules

Follow the active `@task-creation.mdc` Docker rules.

At minimum:

- every `FROM` must be digest-pinned;
- use the canonical final runtime base when one exists;
- justify any allowed non-canonical base;
- keep `environment/` within platform size limits;
- do not include oversized or unnecessary assets;
- pin runtime and verifier dependencies exactly;
- ensure every runtime invoked by source, solution, or tests exists in the
  image;
- do not install dependencies during `tests/test.sh` for offline tasks;
- do not copy `solution/` or `tests/` into the image;
- do not bake answer files or corrected outputs into the image;
- do not use floating image tags;
- do not use `apt upgrade`;
- avoid broad `chmod -R`;
- preserve LF line endings.

Use the currently approved canonical digest and dependency versions from the
active repository policy. Do not copy stale versions from an old task.

### Internet policy

Set `[environment].allow_internet` accurately in `task.toml`.

Use:

```toml
allow_internet = false
```

for a fully offline task. Bake every runtime and verifier dependency into the
Docker image.

Use:

```toml
allow_internet = true
```

only when successful task completion genuinely requires external information
or an unbundleable remote resource.

Do not enable internet merely to simplify dependency installation.

### Optional resource fields

`gpus`, `gpu_types`, and `docker_flags` are optional. Omit them unless the
approved spec requires them.

### Forbidden environment contents

Do not place these under `environment/`:

- generated outputs,
- answer files,
- oracle goldens,
- solved source copies,
- build artifacts,
- package caches,
- AI scratch files,
- `bin/`,
- `out/`,
- `output/`,
- `dist/`,
- `target/`,
- `node_modules/`,
- `__pycache__/`.

A path with one of these names is allowed only when it is genuine unsolved
input required by the spec and passes all repository checks. Do not use such a
path casually.

---

## 10. Oracle-solution rules

`solution/solve.sh` must:

- implement the complete intended solution;
- operate only through legitimate task surfaces;
- avoid modifying tests or verifier code;
- avoid hardcoded test-specific answers;
- avoid bypasses and reward manipulation;
- be deterministic;
- be rerunnable from a clean task state;
- preserve the public contract;
- use realistic edits comparable to what an agent could make.

When the oracle replaces or patches environment files, target paths must be
comparable to the task tree so collapse and frontier checks can measure the
real change.

Prefer patch-style edits or relative environment-root paths where appropriate.

Do not hide the solution through generated binaries, encoded payloads, or
opaque answer blobs.

---

## 11. Test and verifier construction

Tests must verify the public contract independently of the oracle's literal
implementation.

### Genuine-test requirements

For every test in `tests/test_outputs.py`, confirm:

1. the asserted behavior is documented in `instruction.md` or a visible
   environment surface;
2. the test can fail independently;
3. the test does not depend on an earlier test mutating shared state unless
   explicit setup recreates that state;
4. at least two valid solution approaches could satisfy core behavior;
5. the test checks behavior, not oracle text or patch shape;
6. at least one case can falsify each credited required behavior;
7. variant cases defeat local constant patches and sample overfitting;
8. partial-oracle ablations fail for behavioral reasons;
9. the verifier does not trust agent-produced verdict booleans when it can
   recompute the result;
10. tests do not inspect forbidden implementation details unless the public
    contract explicitly requires them.

### Coverage obligation

Build a requirement-to-test matrix before Harbor validation.

For each public requirement, record:

- public disclosure location,
- positive case,
- falsifying case,
- variant or adversarial case where applicable,
- independent recomputation method,
- partial-fix mutation expected to fail.

No required behavior may receive credit without a case capable of disproving
it.

### Verifier independence

Prefer:

- invariant recomputation,
- generated variants,
- semantic comparison,
- state-transition traces,
- metamorphic checks,
- independently derived expectations.

Avoid relying only on:

- one fixed golden file,
- one happy-path fixture,
- string equality against oracle output,
- source-code grep,
- exact patch shape,
- test-specific constants.

### Difficulty response

If agents solve the task too easily, do not merely:

- raise constants,
- rename symbols,
- add more fixed fixtures,
- hide requirements,
- reduce instruction clarity.

Strengthen the structural verifier and accepted-domain reasoning, or return to
Step 2a for redesign.

---

## 12. Discovery-budget confirmation

For each discovery-budget item in the spec:

1. confirm the discovery exists in the built task;
2. confirm it lives in the planned or an evidence-equivalent location;
3. confirm it materially affects the solution;
4. confirm it is not directly revealed by:
   - `instruction.md`,
   - filenames,
   - directory names,
   - comments,
   - test names,
   - fixture names,
   - runtime errors;
5. confirm the public contract still makes the behavior discoverable without
   revealing the diagnosis.

A discovery item is invalid when it is:

- fake,
- irrelevant,
- duplicated,
- directly named,
- discoverable only through hidden tests.

---

## 13. Discoverability gate

For this gate, solver-visible surfaces include:

- `instruction.md`,
- `environment/`,
- public tests where applicable,
- file and directory names,
- runtime output,
- public source help.

`task.toml`, `output_contract.toml`, and authoring metadata are not sufficient
solver disclosure.

Answer:

1. Does `instruction.md` point to exact code locations or implementation
   details?
2. Do environment files expose markers, flags, annotations, correct values,
   commented-out fixes, or structural hints?
3. Do paths or names state what is broken or what to change?
4. Do test names or assertion messages reveal solution steps rather than
   contract behavior?
5. Does broken runtime output pinpoint the exact fix?
6. Does any decoy or unused file create misleading rather than legitimate
   complexity?
7. Is every tested behavior nevertheless discoverable from public materials?

For questions 1–6, any unjustified `yes` must be corrected.
Question 7 must be `yes`.

Re-run the gate after every relevant edit.

---

## 14. Pre-Harbor local validation

Run:

```bash
python3 scripts/spec_satisfiability.py \
  specs/<task-name>.md \
  --task-dir tasks/<task-name> \
  --strict

python3 scripts/hard_difficulty_predictor.py tasks/<task-name>

python3 scripts/task_runtime_deps.py \
  tasks/<task-name> \
  --strict

python3 scripts/task_gate.py \
  tasks/<task-name> \
  --strict \
  --report-dir /tmp/tb3-gates \
  --skip-harbor

./scripts/check-task.sh \
  --strict \
  --report-dir /tmp/tb3-gates \
  tasks/<task-name>
```

Also run the applicable collapse, verifier-health, mutation, or ablation checks
required by current repository policy.

`check-task.sh` must run during this step because it writes
`.step2b-checksum`.

Do not claim Step 2b complete without a valid checksum.

---

## 15. Pre-Harbor Docker checklist

Before Harbor:

1. `task_runtime_deps.py --strict` passes.
2. Every invoked runtime exists in `environment/Dockerfile`.
3. Pytest and required plugins are pinned to exact versions approved by the
   active repository policy.
4. Every non-standard dependency used by environment source, tests, or
   `solution/solve.sh` is installed in the image.
5. `/opt/verifier` is placed on `PATH` when that layout is used.
6. Offline `tests/test.sh` performs no package-manager or network bootstrap.
7. `solution/` and `tests/` are absent from the built image.
8. No solved source, answer artifact, or hidden golden is present in the image.
9. Rebuild the image after every Dockerfile, dependency, or `tests/test.sh`
   change.
10. Re-run local gates after the rebuild.

When an exact apt version disappears from the configured repository, inspect
available versions using the repository-approved workflow and update the pin
consistently. Do not replace exact pins with floating package names.

---

## 16. Harbor gate

After all local and genuine-test gates pass, run:

```bash
python3 scripts/harbor_gate.py \
  tasks/<task-name> \
  --oracle \
  --oracle-stress 3 \
  --nop \
  --nop-stress 3
```

Required evidence:

- every oracle run completes successfully;
- every oracle run earns full reward;
- every NOP run fails to earn full reward;
- results are deterministic;
- no run depends on stale image state;
- no hidden network access occurs when `allow_internet = false`.

If Harbor is unavailable:

1. record `HARBOR_UNAVAILABLE`;
2. report all completed local gates;
3. stop;
4. mark Step 2b incomplete.

Do not substitute a local test run for Harbor oracle/NOP evidence.

---

## 17. Collapse early-stop

Apply the active collapse policy.

Stop local patching and emit a Collapse Redesign Report when:

- `collapse_check.py` fails twice with the same root-cause set; or
- collapse checks fail four times in total.

Return to Step 2a when honest correction requires changing:

- paths,
- output schema,
- public contract shape,
- symbol frontier,
- file topology,
- instruction disclosure,
- category profile,
- task shape,
- core verifier strategy.

Do not repair collapse findings using:

- whitespace padding,
- split strings,
- `importlib` or `getattr` hiding,
- homoglyphs,
- cosmetic decoys,
- meaningless file spreading,
- dead code,
- obscured literals,
- removal of externally tested requirements.

Structural redesign is required.

---

## 18. Change discipline

After every failed check:

1. identify the root cause;
2. identify the construction rule that should have prevented it;
3. make the smallest root-cause correction;
4. verify that the change preserves the spec;
5. rerun the failed gate;
6. rerun any downstream gate invalidated by the change.

Do not make unrelated edits.
Do not weaken tests merely to make the oracle pass.
Do not alter the public contract merely to match the current implementation.
Do not preserve a broken design because files have already been created.

Return to Step 2a when the needed correction is architectural.

---

## 19. Completion criteria

Step 2b is complete only when all of the following are true:

- the task uses exactly one accepted category;
- category integrity passes;
- the implementation language matches the spec;
- all required files exist;
- no milestone layout exists;
- instruction disclosure is complete and non-collapsing;
- discovery-budget confirmation passes;
- discoverability gate passes;
- spec satisfiability passes;
- hard-difficulty prediction meets the approved threshold;
- runtime-dependency validation passes;
- task gate passes;
- strict `check-task.sh` passes;
- `.step2b-checksum` exists and is current;
- genuine-test and requirement-to-test checks pass;
- collapse checks pass;
- Harbor oracle stress passes with full reward;
- Harbor NOP stress does not earn full reward;
- the task remains consistent with the finalized Step 2a spec.

If Harbor is unavailable, Step 2b is not complete.

---

## 20. Report and stop

Report only:

1. accepted category and category-integrity verdict;
2. implementation language;
3. files created under `tasks/<task-name>/`;
4. discovery-budget confirmation;
5. discoverability-gate answers;
6. requirement-to-test and falsification coverage;
7. `spec_satisfiability` verdict;
8. hard-difficulty prediction;
9. runtime-dependency verdict;
10. `task_gate` verdict;
11. collapse and verifier-health verdicts;
12. `check-task.sh --strict` result and checksum status;
13. Harbor oracle/NOP results or `HARBOR_UNAVAILABLE`;
14. every check that did not pass on the first attempt and the missed
    construction rule;
15. whether Step 2b is complete.

Then stop.

Do not package.
Do not approve.
Do not submit.
Do not run oracle 10 times.
Do not produce `ACCEPT` or `REJECT`.

---

## Authoring spec path

```text
specs/<task-name>.md
```
