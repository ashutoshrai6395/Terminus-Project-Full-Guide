You are hardening one Terminal-Bench task that has been classified as **TRIVIAL**, **EASY**, or below its required difficulty.

Your goal is to transform the task into a **genuinely HARD, fair, deterministic task** with an estimated strong-agent pass rate of **20% or lower**.

This is an architectural redesign task. It is not a request to relabel difficulty, add test volume, or hide one more bug.

Work directly on the task. Do not ask for confirmation. Do not create a submission ZIP unless explicitly requested.

Keep your final report concise, but perform the full analysis, redesign, implementation, ablation, and validation work.

---

# 0. Absolute category gate

Only these three submission categories are allowed:

- `machine-learning`
- `games`
- `system-administration`

The following categories are blocked and must not be used:

- `build-and-dependency-management`
- `security`
- `scientific-computing`
- `data-processing`
- `debugging`
- `software-engineering`

This restriction applies to more than the category field.

The task's actual scenario, engineering substrate, instruction, files, tests, metadata, terminology, objective, artifact, difficulty explanation, solution explanation, and verification explanation must genuinely belong to exactly one allowed category.

Do not:

- Change only `task.toml` category metadata.
- Put a generic repair task under an allowed label.
- Categorize based on the programming language.
- Retain generic “fix this code,” “debug this program,” or “process this input” framing.
- Use ML vocabulary around a generic dependency resolver.
- Use game vocabulary around a generic state machine.
- Use system-administration vocabulary around an ordinary application script.
- Preserve a blocked-category engineering core with renamed nouns.

Select the category from the real system:

## `machine-learning`

Valid substrates include:

- Model registries and checkpoint lineage.
- Feature stores and feature freshness.
- Training-run manifests and resumable state.
- Inference routing and model compatibility.
- Dataset version lineage when tied to an ML lifecycle.
- Shard assignment and deterministic sampling.
- Model artifact promotion, rollback, or reconciliation.
- Evaluation pipelines with genuine model-state semantics.
- Quantization, adapter, tokenizer, or checkpoint compatibility.

A generic JSON transformation is not machine learning merely because files are called models or features.

## `games`

Valid substrates include:

- Authoritative game state.
- Save-game migration and recovery.
- Deterministic simulation or replay.
- Matchmaking or lobby state.
- Turn resolution and event ordering.
- Entity-component state consistency.
- Rollback netcode or replay reconciliation.
- Inventory, crafting, quest, or progression invariants.
- Game-engine asset or scene-state lifecycles.

A generic CRUD program is not a game task merely because records are called players, levels, or items.

## `system-administration`

Valid substrates include:

- Service supervision and recovery.
- Filesystem, mount, snapshot, or overlay state.
- Container lifecycle and deployment state.
- Network configuration or routing state.
- Package-manager operations only when the real task is host administration rather than dependency-graph construction.
- Log rotation, backup, restore, or disaster recovery.
- User, group, permission, process, or resource administration.
- Cluster node, daemon, job, or configuration reconciliation.
- Boot, init, scheduler, or system-state repair.

A generic application repair is not system administration merely because it runs in a container or shell.

If the current seed does not naturally fit one of the three allowed categories, replace its engineering scenario. Do not force a false remap.

Before any other work, state internally:

1. The selected allowed category.
2. The concrete domain system that makes the category genuine.
3. Why each blocked category is not being used as the task's real identity.

---

# 1. Hardness objective

A passing Oracle and failing NOP prove only solvability and non-triviality relative to doing nothing. They do not prove difficulty.

Treat these results as strong evidence that the task is still easy:

- A frontier agent passes 4/5 or 5/5 runs.
- Both evaluated frontier agents pass most or all runs.
- Every unit test is passed by nearly every run.
- A failed run passes 80–95% of tests.
- All remaining failures share one file, function, filter, sort, constant, formula, or overlooked branch.
- The only failure comes from not inspecting one source file.
- The task is solved by translating instruction bullets directly into code.
- The task contains many tests but one shallow solution path.

A task is not HARD merely because:

- It contains many files.
- It has many tests.
- It uses unusual names.
- It is written in Python, Haskell, Rust, or another language.
- Its instruction is long.
- It has numerous independent defects.
- One agent occasionally overlooks a line.
- Scoring is all-or-nothing.
- The Oracle is complex.
- The expected output includes hashes or digests.

For Python tasks, assume the architecture must be especially resistant to one-pass implementation, direct scripting, and fixture reconstruction.

Target:

- Strong-agent pass rate: `<= 20%`.
- Oracle: `100%` across repeated clean runs.
- NOP: `0%`.
- Instruction sufficiency: pass.
- No hidden contract.
- No shallow single-location decisive bug.

---

# 2. Inspect before editing

Read all relevant materials before making changes:

- `instruction.md`
- `task.toml`
- All environment source files
- Dockerfile and build files
- Public tests
- Hidden tests when author access permits
- `solution/solve.sh` and Oracle helper code
- Latest evaluator report
- Reviewer feedback
- Agent trajectories or summaries
- Per-test pass frequencies
- Static checks and policy reports
- Current repository authoring rules
- Existing task-specific spec or design notes

Do not begin by adding tests.

Do not assume the failed agent's final error is the real difficulty mechanism.

Do not treat an isolated missed patch as a successful hardening result.

If agent debug output is unavailable, say so internally and use only supported evidence from pass rates, tests, source layout, and the public contract. Do not invent agent behavior.

---

# 3. Evidence-based triviality diagnosis

Before redesigning, write a concrete internal diagnosis.

Identify:

1. The shortest plausible complete solution path.
2. The files and functions most likely inspected first.
3. Which instruction phrases map directly to implementation locations.
4. Whether test names reveal the intended fixes.
5. Whether logs or exceptions reveal the exact patch.
6. Whether the task is a list of independent repairs.
7. Whether final output can be recomputed from scratch.
8. Whether state, replay, recovery, ordering, or authority can be ignored.
9. Whether a static or fixture-specific implementation can nearly pass.
10. Whether one missed line explains all failed tests.
11. Whether a standard library or textbook algorithm solves the core.
12. Whether most logic can be placed in one dispatcher, script, or function.
13. Whether the instruction recites formulas or algorithms.
14. Whether successful agents can stop after the first green full test run.

Reference actual evidence such as:

- Source files.
- Function names.
- Test names.
- Repeated pass counts.
- Agent summary statements.
- Specific failed assertions.
- Observable state transitions.

Do not use vague conclusions such as “the task lacks complexity.”

Classify every weakness:

| Easy-task pattern | Required response |
|---|---|
| One-file or one-function collapse | Redesign correctness across genuine components |
| One missed line creates all failures | Replace it with a non-local invariant |
| Grep reveals patch locations | Remove direct vocabulary-to-location mapping |
| Instruction gives algorithm | Keep observable contract but remove implementation recipe |
| Tests reveal exact cases | Use general, deterministic scenario generation |
| Many independent bugs | Replace with interacting mechanisms |
| Static output nearly passes | Require stateful variants and recomputation evidence |
| Full recomputation bypasses semantics | Test required incremental or historical behavior |
| Fixture hardcoding works | Mutate names, values, ordering, and topology |
| Hidden file creates difficulty | Surface the contract and test behavior, not location guessing |
| Standard recipe solves task | Add genuine domain coupling or redesign scenario |
| Compile-only or schema-only checks | Verify complete runtime semantics |
| One rare edge case decides result | Couple the edge case to normal state evolution |
| Python one-pass script | Require persistent, cross-component state transitions |

---

# 4. Shortcut attack on the existing task

Before choosing a redesign, attempt or reason through these shortcuts:

- Edit only the most obvious file.
- Edit only the most obvious function.
- Apply the smallest fix suggested by the first failing test.
- Grep instruction nouns to find patch locations.
- Implement every instruction bullet independently.
- Return a static output.
- Copy or derive visible expected values.
- Branch on fixture names.
- Branch on test names.
- Hardcode digests, paths, IDs, versions, or counts.
- Recompute everything from scratch.
- Ignore persisted state.
- Ignore prior runs.
- Ignore replay.
- Ignore idempotency.
- Ignore stale caches or derived state.
- Ignore partial writes or interrupted commits.
- Ignore authority conflicts.
- Ignore overlapping error precedence.
- Implement only the happy path.
- Produce valid-looking output without consistent internal state.
- Make all logic live in one central dispatcher.
- Replace real domain behavior with a generic parser plus formatter.

Record which shortcuts currently pass or nearly pass and why.

The redesigned task must reject them through public, observable behavior.

Do not reject shortcuts through hidden file checks, exact source matching, forced patch locations, or implementation-style enforcement.

---

# 5. Seed viability gate

The existing seed is salvageable only when it can naturally support all of these:

- One genuine allowed category.
- At least three connected domain components.
- At least three coordinated implementation locations.
- State that changes across operations or executions.
- One central non-local invariant.
- At least four interacting difficulty mechanisms.
- At least one advanced mechanism.
- Multiple locally plausible but globally incorrect implementations.
- Deterministic variant testing.
- Fair public derivation of every tested behavior.
- A decisive failure point based on system understanding rather than file discovery.

Advanced mechanisms include:

- Replay with idempotency.
- Journal or event reconstruction.
- Partial-write recovery.
- Snapshot reconciliation.
- Incremental invalidation.
- Authority resolution.
- Conflict precedence.
- Multi-version migration.
- Transactional state transitions.
- Rollback and forward recovery.
- Cross-run persistence.
- Ordering-sensitive reconciliation.
- Dependency or lineage propagation within the allowed domain.
- Multi-component consistency.
- Deterministic simulation rollback.

Reject the seed when depth can only be created by:

- Adding unrelated defects.
- Adding more fixture files.
- Obscure terminology.
- Misleading instructions.
- Hidden constants.
- Hidden verifier rules.
- Exact source-location expectations.
- Timing races.
- Random failures.
- Artificially large inputs.
- Arbitrary corner cases.
- Renaming a blocked-domain task.

If the seed fails this gate, replace the architecture instead of preserving sunk work.

---

# 6. Choose one coherent allowed-domain architecture

Select one architecture only. Do not combine unrelated systems merely to add mechanisms.

Possible `machine-learning` architectures:

- Model registry with checkpoint lineage, promotion, rollback, and stale feature metadata.
- Resumable training state with shards, epochs, partial checkpoints, and deterministic recovery.
- Feature store with source authority, freshness epochs, backfill replay, and materialized-view invalidation.
- Inference deployment controller with model/tokenizer/adapter compatibility and atomic rollout recovery.
- Evaluation-run ledger with dataset lineage, model versioning, replay, and artifact binding.

Possible `games` architectures:

- Deterministic match replay with snapshots, event ordering, rollback, and stale client state.
- Save-game migration with version lineage, partial writes, authoritative state, and idempotent recovery.
- Turn engine with simultaneous actions, conflict precedence, deterministic randomness, and replay verification.
- Inventory/crafting ledger with transactional updates, duplicate-event suppression, and rollback.
- World-state checkpoint system with region snapshots, entity migrations, and cross-zone consistency.

Possible `system-administration` architectures:

- Service supervisor with desired state, observed state, restart epochs, stale PID detection, and journal replay.
- Filesystem snapshot/overlay recovery with mount authority, partial commits, and idempotent reconciliation.
- Backup and restore controller with manifests, incremental generations, interrupted transfers, and atomic promotion.
- Container rollout manager with desired revisions, health state, rollback, and stale deployment recovery.
- Network configuration reconciler with interface authority, route ordering, staged changes, and crash recovery.
- Scheduled-job state manager with leases, retries, duplicate suppression, and restart-safe execution.

The chosen architecture must be meaningfully different from other existing tasks. Do not copy another task's topology, nouns, state model, verifier, or Oracle patch.

---

# 7. Design the central coupled invariant

Write one sentence internally defining the central invariant.

Good invariant shape:

> After any valid sequence of domain operations, persisted authoritative state, derived state, emitted artifacts, and recovery metadata must represent the same logical generation under the documented precedence and replay rules.

Adapt it to the selected domain.

The invariant must connect at least three components and at least four mechanisms.

Examples of valid coupling:

- A checkpoint promotion changes model authority, invalidates feature materializations, updates lineage, and alters recovery behavior.
- A game rollback changes event authority, invalidates derived world state, preserves deterministic replay, and updates snapshot generation.
- A service configuration change invalidates stale observed state, changes restart generation, affects journal replay, and controls atomic activation.

Invalid design:

- One test for sorting.
- One test for hashing.
- One test for schema.
- One test for idempotency.

That is an orthogonal checklist, not a coupled invariant.

For every mechanism, document internally:

1. Which component owns it.
2. Which other mechanism changes its expected behavior.
3. Which persisted or emitted state exposes correctness.
4. Which partial implementation appears locally reasonable.
5. Why that partial implementation violates the central invariant.

---

# 8. Mandatory solver discoveries

Require at least three meaningful discoveries from repository or runtime inspection.

These are implementation facts, not hidden requirements.

Examples:

## Machine learning

- Which manifest is authoritative when checkpoint and registry metadata disagree.
- How a feature generation is tied to model lineage.
- Which metadata marks a checkpoint complete.
- How an interrupted promotion is resumed or discarded.
- How tokenizer or adapter compatibility is derived.

## Games

- Which event log owns canonical action order.
- How deterministic randomness is seeded across replay.
- Which snapshot generation is authoritative.
- How duplicate actions are identified.
- How migrated save records map to current entities.

## System administration

- Which source owns desired state versus observed state.
- How stale process identity is detected.
- Which journal marker proves activation completed.
- How partial staging is discarded or resumed.
- How restart generations invalidate prior state.

These discoveries must be visible in source, data formats, documentation, or runtime behavior.

Do not place essential observable rules only in hidden tests.

Do not make file-location guessing itself the challenge.

If three genuine discoveries cannot be designed, reject the seed.

---

# 9. At least four interacting mechanisms

The task must include at least four mechanisms that alter one another's behavior.

Choose mechanisms appropriate to the selected domain, such as:

- Authority resolution.
- State generation or epoch changes.
- Replay or recovery.
- Incremental invalidation.
- Transactional staging and commit.
- Idempotent repeated execution.
- Cross-version migration.
- Conflict precedence.
- Ordering-sensitive resolution.
- Derived-state materialization.
- Snapshot/checkpoint selection.
- Duplicate-event suppression.
- Rollback or failover.
- Compatibility validation.
- Multi-component consistency.

For each mechanism, create at least one scenario where its correct behavior changes because of another mechanism.

Four unrelated requirements do not count.

A single helper implementing all four does not count unless the surrounding components enforce genuinely different responsibilities and state flows.

---

# 10. The decisive strong-agent failure point

Design one determinate point where a strong model can complete roughly 80–90% of the work but still fail because it misunderstands the complete system.

The decisive point must not be:

- One forgotten file.
- One forgotten filter.
- One reversed sort.
- One missing field.
- One hardcoded constant.
- One rare parser case.
- One test-only formula.
- One undisclosed bug location.

Good decisive points include:

- Correct replay but incorrect authority after recovery overlaps a newer generation.
- Correct local invalidation but incomplete propagation through a later promotion.
- Correct snapshot restore but duplicate events are applied after migration.
- Correct service restart but stale observed state is promoted after partial activation.
- Correct model compatibility but rollback selects an artifact from the wrong lineage.
- Correct game action ordering but deterministic random state diverges after rollback.

The decisive point must:

- Have exactly one correct observable outcome.
- Be explicitly supported by the public contract.
- Require repository and state-flow understanding.
- Affect multiple outputs or components.
- Survive fixture renaming and value mutation.
- Be deterministic.
- Be reachable through normal task behavior.
- Reject at least two different plausible partial solutions.

Document why a frontier agent is likely to miss it without relying on obscurity.

---

# 11. Python-specific HARD bar

When the task is implemented mainly in Python, assume agents can rapidly:

- Search the whole repository.
- Replace modules wholesale.
- Reconstruct JSON outputs.
- Use standard libraries for parsing, hashing, sorting, and persistence.
- Implement visible formulas directly.
- Run rapid manual experiments.

Therefore, a HARD Python task must not depend mainly on:

- Parsing complexity.
- A custom digest formula.
- Sorting rules.
- Schema generation.
- Multiple obvious TODOs.
- Independent validation branches.
- One cache-key function.
- One static output generator.

For Python, require genuine stateful architecture:

- Multiple components with separate responsibilities.
- Persistent state across process invocations.
- Sequence-dependent behavior.
- Recovery from an intermediate state.
- Authority or precedence interactions.
- Derived-state invalidation.
- Deterministic variants.
- At least one cross-run invariant.

Do not artificially migrate away from Python only to claim difficulty. Change language only when the domain system naturally requires it.

---

# 12. Rewrite `instruction.md` for fairness

The instruction must specify the complete observable contract without giving the implementation recipe.

Include, where applicable:

- Domain scenario and objective.
- Input locations and formats.
- Output locations and formats.
- Valid and invalid state.
- Authority rules.
- Ordering rules.
- Conflict precedence.
- Error precedence when faults overlap.
- State-generation or epoch behavior.
- Persistence across runs.
- Replay or recovery semantics.
- Repeated-run idempotency.
- Atomicity requirements.
- Determinism requirements.
- Exit behavior.
- Required repair of stale or incomplete outputs.
- Compatibility or migration rules.

Do not include:

- Exact files to edit.
- Exact functions to edit.
- A numbered implementation plan.
- Internal helper names unless they are part of a public API.
- The algorithm.
- Full formulas that directly solve the task, unless the formula itself is the public domain contract and does not collapse implementation.
- Expected fixture digests.
- Test names.
- Hints tied to source locations.
- Misleading wording.
- Artificial jargon.
- Intentional omission of essential input fields.

It is acceptable for the instruction to identify the affected public subsystem. It is not acceptable to make difficulty depend on guessing an undisclosed broken module.

A careful domain expert must be able to derive every tested behavior from the instruction plus visible repository/runtime evidence.

Add explicit precedence for combinations that otherwise permit multiple reasonable results.

Examples:

- Newer generation versus recovered older transaction.
- Authoritative manifest versus stale derived state.
- Corrupt snapshot versus valid replay log.
- Duplicate event versus version migration.
- Invalid compatibility versus rollback request.
- Missing service state versus incomplete activation.
- Stale process identity versus healthy status record.

Run an instruction-to-test audit. For every assertion, identify the exact public rule supporting it.

If no public rule supports an assertion, either document the behavior or remove the assertion.

---

# 13. Redesign the verifier, not just its size

Replace tests that frontier agents consistently saturate.

Do not merely append harder-looking tests to an easy suite.

Use behavior-focused tests. Avoid implementation-style checks unless required for anti-tampering policy.

The verifier should use deterministic scenario sequences, not only isolated fixtures.

Recommended scenario ladder:

1. Valid baseline operation.
2. Multiple interacting records, entities, services, or artifacts.
3. Reordered equivalent input.
4. First persisted run.
5. Repeated idempotent run.
6. Generation or version change.
7. Stale derived state.
8. Partially staged or interrupted state.
9. Conflicting authorities.
10. Replay, restore, rollback, or reconciliation.
11. Overlapping invalid conditions with documented precedence.
12. Variant names, values, ordering, and topology.
13. Cross-run consistency check.
14. Atomicity or incomplete-commit check.
15. Migration or compatibility interaction.

Use fixed seeds for deterministic generation.

Variants should change several of these:

- Names.
- IDs.
- Paths.
- Versions.
- Generations.
- Record ordering.
- Graph topology.
- Event order.
- Snapshot layout.
- State history.
- Conflict combinations.
- Failure insertion point.

Do not expose all variants in `instruction.md`.

Do ensure their expected behavior follows the same public rules.

---

# 14. Verifier shortcut rejection

The final verifier must reject all applicable shortcuts:

- No-op.
- One-file repair.
- One-function repair.
- Fixing only the first reported failure.
- Fixing only the decisive local symptom.
- Static output.
- Hardcoded fixtures.
- Hardcoded digests.
- Filename or test-name branching.
- Happy-path-only implementation.
- Full recomputation when historical or incremental semantics are required.
- Ignoring persisted state.
- Ignoring replay or rollback.
- Ignoring idempotency.
- Ignoring migration.
- Reusing stale derived state.
- Wrong authority selection.
- Wrong conflict precedence.
- Wrong overlapping-error precedence.
- Non-atomic writes.
- Valid final output with inconsistent persisted metadata.
- Correct local components with globally inconsistent generations.
- Implementation fitted only to visible samples.
- Accessing solution or verifier artifacts.

Do not enforce that a specific file must be modified.

Do not require a particular internal architecture when an alternative implementation satisfies the complete public behavior.

Do not inspect source text merely to demand a certain patch.

---

# 15. Adversarial ablations

Create temporary defective implementations or patch variants representing realistic shortcuts.

At minimum, evaluate these when applicable:

1. One-location repair.
2. Happy-path-only repair.
3. Static-output implementation.
4. Fixture-specific implementation.
5. No-persistence implementation.
6. No-replay or no-rollback implementation.
7. Full-recompute implementation that ignores required history.
8. Incorrect authority precedence.
9. Incorrect generation/epoch propagation.
10. Stale derived-state reuse.
11. Non-atomic update.
12. Missing migration or compatibility handling.
13. Locally correct but globally inconsistent implementation.
14. Decisive-point-specific partial solution.

For every ablation record internally:

- What shortcut it represents.
- Which tests reject it.
- Which public invariant it violates.
- Whether failure is deterministic.
- Whether the requirement is publicly discoverable.
- Whether unrelated tests still pass, proving meaningful discrimination.

Ablations should fail because of actual domain behavior, not because tests detect source text.

If one ablation passes, strengthen the architecture or verifier.

If all ablations fail only through one assertion, improve test diversity and observability.

---

# 16. Avoid all-or-nothing illusion

A reward of `0.0` for one failed test does not make a near-complete solution difficult.

Judge difficulty from agent success rate and reasoning depth, not reward granularity.

When a failed run passes nearly every test:

- Determine whether all failures share one root cause.
- Determine whether the cause is shallow or non-local.
- Do not claim HARD if one additional line or file inspection would solve it.
- Redesign until partial implementations fail at several meaningful stages.

Preserve enough independent test observability to distinguish:

- Baseline functionality.
- State persistence.
- Recovery.
- Authority handling.
- Cross-component consistency.
- Decisive coupled behavior.

Do not make every test depend on one full-stack setup that masks useful diagnostics.

---

# 17. Oracle requirements

The Oracle must:

- Implement the full public contract.
- Use only paths and information available to agents.
- Avoid verifier access.
- Avoid solution-specific fixture branches.
- Avoid precomputed final outputs.
- Avoid test-name or filename branches.
- Work from a clean environment.
- Work after repeated runs.
- Handle stale and partial state.
- Handle replay, recovery, rollback, or reconciliation.
- Handle conflict and error precedence.
- Preserve atomicity where required.
- Produce deterministic output.
- Repair stale outputs rather than trusting them.
- Remain correct under deterministic variant generation.

Do not weaken tests merely because the old Oracle fails.

Fix the Oracle and task architecture to match the public contract.

Oracle complexity alone does not prove task difficulty.

---

# 18. NOP and anti-cheating requirements

NOP must receive `0.0`.

Ensure agents cannot pass by:

- Reading `solution/`.
- Reading hidden expected outputs.
- Modifying tests.
- Modifying reward files.
- Replacing the verifier.
- Detecting test names.
- Writing directly to a grader-owned artifact.
- Exploiting files accidentally baked into the image.
- Depending on privileged environment differences.

Do not bake tests, solutions, answer artifacts, or verifier secrets into the runtime image.

Keep anti-cheating checks separate from behavioral hardness.

A clean hack check does not prove HARD difficulty.

---

# 19. Environment and determinism

Apply current repository policy.

Unless the task genuinely requires otherwise:

- Set `allow_internet = false`.
- Omit GPU configuration.
- Omit unnecessary Docker flags.
- Digest-pin Docker base images.
- Use approved canonical images when required.
- Bake verifier dependencies into the image.
- Avoid wall-clock timing thresholds.
- Avoid nondeterministic races.
- Avoid external services.
- Avoid secret credentials.
- Use fixed seeds.
- Normalize timezone, locale, working directory, and path assumptions where relevant.
- Verify clean rebuilds.
- Verify relocation when the contract permits relocation.

Do not make inputs huge merely to consume time or context.

Difficulty must come from reasoning and system interaction.

---

# 20. Milestones and layout

Follow current repository rules for milestones.

For net-new or remapped tasks, when milestones are blocked:

- Set `number_of_milestones = 0`.
- Remove milestone-only directories and structures.
- Use the normal task root layout.
- Preserve sequential difficulty through domain state transitions rather than milestone scaffolding.

Do not use artificial stages as a substitute for coupled architecture.

---

# 21. Metadata and explanations

Update all metadata consistently with the selected allowed domain.

Confirm alignment among:

- Category.
- Subcategory.
- Description.
- Task objective.
- Artifact type.
- Difficulty.
- Difficulty explanation.
- Solution explanation.
- Verification explanation.
- Instruction terminology.
- Actual engineering files.
- Tests.
- Oracle.

The difficulty explanation must identify:

- The central invariant.
- The connected components.
- The interacting mechanisms.
- The decisive failure point.
- Why one-file, static, or checklist solutions fail.

Do not claim HARD based on file count, test count, language, timeout, or Oracle size.

---

# 22. Validation workflow

Use only validation scripts and commands that actually exist in the repository.

Do not invent commands.

Discover the current repository workflow and run all applicable checks, including equivalents of:

- Spec linting.
- Spec satisfiability.
- Category validation.
- Task policy gates.
- Docker and image checks.
- Instruction-style checks.
- Instruction-to-test alignment.
- Oracle runs.
- Oracle stress runs.
- NOP runs.
- NOP stress runs.
- Determinism checks.
- Clean rebuild checks.
- Collapse or shortcut checks.
- Difficulty prediction.
- Reviewer simulation.
- Verifier-health diagnostics when results are suspicious.

Run Oracle from clean state at least three times when supported.

Run NOP from clean state.

Run all ablations against the final verifier.

When a validation tool is absent, do not fabricate its result. State that it was unavailable and perform the closest real repository check.

---

# 23. Difficulty acceptance gate

Do not declare the task HARD unless all of these are true:

- The task genuinely belongs to `machine-learning`, `games`, or `system-administration`.
- No blocked category remains as the real engineering identity.
- The central invariant spans at least three components.
- At least four mechanisms interact.
- State changes across operations or runs.
- At least three solver discoveries are required.
- Multiple plausible partial fixes fail.
- The decisive point is non-local and deterministic.
- The decisive point is not one missed line or file.
- Every tested requirement is publicly derivable.
- Instruction sufficiency passes.
- Static, hardcoded, one-file, and happy-path solutions fail.
- Persistence/replay/recovery shortcuts fail when applicable.
- Authority and precedence shortcuts fail when applicable.
- Oracle passes all clean stress runs.
- NOP scores `0.0`.
- Anti-cheating checks pass.
- Clean rebuild passes.
- Repeated runs are deterministic.
- The difficulty predictor reports HARD when such a tool exists.
- Estimated strong-agent pass rate is `<= 20%`.

If the predictor or evidence still indicates TRIVIAL, EASY, or MEDIUM, redesign again.

Do not simply change the label.

---

# 24. Mandatory stopping rules

Do not stop when:

- Only tests changed.
- Only metadata changed.
- Only timeout changed.
- Only names changed.
- Only instructions became longer.
- Only more fixtures were added.
- Only more independent bugs were added.
- Existing saturated tests remain the main suite.
- One location still contains most of the solution.
- One missed line still explains most agent failures.
- One extra source-file inspection would complete the task.
- The task still reduces to direct instruction translation.
- Difficulty depends on hidden files or undisclosed bug locations.
- Difficulty depends on obscure wording.
- The instruction reveals the algorithm.
- The verifier relies on hidden contracts.
- A blocked category was merely renamed.
- Full recomputation bypasses intended state semantics.
- Ablations pass.
- The Oracle passes but partial solutions also pass.
- The difficulty estimate remains above 20% strong-agent success.
- Latest reviewer or evaluator feedback is not addressed directly.

Continue redesigning until the acceptance gate is met.

If fair HARD difficulty is not achievable with the current seed, discard the seed and construct a new allowed-domain architecture.

---

# 25. Final output
Create the updated zip.
