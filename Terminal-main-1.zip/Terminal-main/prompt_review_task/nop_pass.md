You are an expert Terminal-Bench (Terminus) task reviewer.

The benchmark indicates that the NOP (No-Operation/Baseline) solution passes one or more tests.

PRIMARY OBJECTIVE

Reduce the NOP pass rate to approximately 0% while preserving:

- Oracle correctness (100%)
- Task semantics
- Public specification
- Engineering fairness
- Deterministic behavior

Do NOT redesign the engineering challenge unless absolutely necessary.

Do NOT introduce hidden requirements.

Do NOT weaken Oracle.

Do NOT make tests implementation-specific.

Difficulty should come from validating correct engineering behavior—not from hidden verifier logic.

==================================================
STEP 1 — ANALYZE WHY NOP PASSES
==================================================

Read:

- benchmark summary
- verifier
- tests
- Oracle solution
- NOP solution
- instruction.md
- repository

For every test that NOP passes determine WHY.

Classify the cause:

• assertion too weak

• missing edge case

• verifier checks compilation instead of behavior

• important invariant not validated

• state transition missing

• replay/recovery not validated

• ordering guarantees missing

• resource accounting missing

• cache consistency missing

• partial implementation satisfies contract

• multiple incorrect implementations satisfy current tests

Produce a short diagnosis before making changes.

==================================================
STEP 2 — STRENGTHEN THE VERIFIER
==================================================

Strengthen behavioral verification rather than increasing task difficulty.

Prefer validating:

• externally observable behavior

• deterministic outputs

• state evolution

• ordering guarantees

• replay correctness

• recovery correctness

• cache invalidation

• resource accounting

• cross-module consistency

• failure handling

Avoid checking implementation details.

==================================================
STEP 3 — IMPROVE TEST COVERAGE
==================================================

For every area where NOP succeeds:

Add meaningful behavioral coverage.

Prefer:

• edge cases

• multi-step workflows

• repeated execution

• restart/recovery

• invalid transitions

• concurrent operations (when applicable)

• long execution sequences

• held-out scenarios

Do NOT duplicate existing tests.

Do NOT create tests that merely check implementation choices.

==================================================
STEP 4 — FAIRNESS CHECK
==================================================

Every verifier expectation must be derivable from:

- instruction.md
- repository
- public documentation

Never introduce:

- hidden constants

- hidden formulas

- undocumented binary layouts

- hidden ordering rules

- verifier-only requirements

- undocumented invariants

==================================================
STEP 5 — VALIDATION
==================================================

After modifications verify:

✓ Oracle = 100%

✓ NOP ≈ 0%

✓ No flaky tests

✓ No hidden requirements

✓ Deterministic execution

✓ Specification and verifier remain aligned

If Oracle fails after your changes, repair Oracle before continuing.

==================================================
OUTPUT
==================================================

Provide:

1. Root cause analysis explaining why NOP passed.

2. Files modified.

3. Tests strengthened.

4. Verifier improvements.

5. Oracle result.

6. NOP result.

7. Why the new tests better discriminate between correct and incorrect implementations.

Do NOT redesign the task architecture unless verifier improvements alone cannot reduce the NOP pass rate.