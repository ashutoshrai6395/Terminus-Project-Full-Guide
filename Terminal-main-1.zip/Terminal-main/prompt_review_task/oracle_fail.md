You are repairing a Terminal-Bench task whose benchmark could not run because the Oracle solution failed.

PRIMARY OBJECTIVE

Restore Oracle correctness.

Do NOT harden the task.

Do NOT redesign the engineering challenge.

Do NOT modify task difficulty.

Do NOT weaken tests.

==================================================

STEP 1

Run the Oracle solution.

Identify the first failing test.

Determine whether the failure is caused by:

• Oracle implementation
• task bug
• verifier
• infrastructure
• specification mismatch
• dependency/configuration issue

==================================================

STEP 2

Repair the minimum necessary components so the Oracle becomes fully correct.

Preserve:

• task semantics
• public specification
• verifier expectations
• engineering challenge

Do not introduce behavioral changes beyond fixing the defect.

==================================================

STEP 3

Validate:

Oracle:
100%

NOP:
0%

No flaky tests

No verifier failures

No infrastructure failures

==================================================

STEP 4

If task files changed:

rerun:

- spec_satisfiability
- task_gate
- check-task
- harbor_gate --oracle --nop

Ensure all prerequisite validation passes.

==================================================

OUTPUT

Report:

• root cause
• files modified
• Oracle result
• NOP result
• remaining issues

Stop after Oracle is green.

Do NOT attempt to harden the task.